from __future__ import annotations

import argparse
import html
import json
import math
import random
from dataclasses import asdict, dataclass
from datetime import timedelta, timezone
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import pandas as pd
from binance.client import Client


DEFAULT_SYMBOL = "BTCUSDT"
DEFAULT_START = "2023-07-17"
DEFAULT_END = "2026-10-04"
CACHE_DIR = Path("data")
REPORT_DIR = Path("reports")
IST = timezone(timedelta(hours=5, minutes=30), name="IST")

KLINE_COLUMNS = [
    "open_time",
    "open",
    "high",
    "low",
    "close",
    "volume",
    "close_time",
    "quote_volume",
    "trade_count",
    "taker_buy_base_volume",
    "taker_buy_quote_volume",
    "ignore",
]

TIMEFRAME_RULES = {
    "1h": "1h",
    "2h": "2h",
    "3h": "3h",
    "4h": "4h",
    "6h": "6h",
    "8h": "8h",
    "12h": "12h",
}


def status(message: str) -> None:
    """Print a progress message immediately, including when stdout is redirected."""
    print(f"[status] {message}", flush=True)


@dataclass
class Metrics:
    total_return_pct: float
    final_equity: float
    cagr_pct: float
    max_drawdown_pct: float
    sharpe_like: float
    trades: int
    exposure_pct: float
    cycle_count: int
    positive_cycles: int
    min_cycle_return_pct: float
    avg_cycle_return_pct: float
    blown_up: bool


@dataclass
class ExecutionPath:
    """The realised, bar-by-bar path after cycle controls are applied."""

    returns: pd.Series
    unit_position: pd.Series
    equity: pd.Series
    blown_up: bool
    exit_reason: pd.Series


def utc_timestamp(value: str) -> pd.Timestamp:
    ts = pd.Timestamp(value)
    if ts.tzinfo is None:
        ts = ts.tz_localize("UTC")
    return ts.tz_convert("UTC")


def ist_timestamp(value: str | pd.Timestamp) -> pd.Timestamp:
    ts = pd.Timestamp(value)
    if ts.tzinfo is None:
        ts = ts.tz_localize("UTC")
    return ts.tz_convert(IST)


def ist_iso(value: str | pd.Timestamp) -> str:
    return ist_timestamp(value).isoformat()


def ist_display(value: str | pd.Timestamp) -> str:
    return ist_timestamp(value).strftime("%Y-%m-%d %H:%M:%S IST")


def ist_indexed(series: pd.Series) -> pd.Series:
    result = series.copy()
    result.index = pd.DatetimeIndex(result.index).tz_convert(IST)
    return result


def fetch_binance_klines(
    symbol: str,
    start: str,
    end: str,
    cache_dir: Path = CACHE_DIR,
) -> pd.DataFrame:
    cache_dir.mkdir(parents=True, exist_ok=True)
    cache_file = cache_dir / f"{symbol}_1h_{start}_{end}.csv"
    status(f"Checking for cached 1h {symbol} data: {cache_file}")
    if cache_file.exists():
        status("Cache found; loading historical candles from disk.")
        df = pd.read_csv(cache_file, parse_dates=["open_time"], index_col="open_time")
        df.index = pd.DatetimeIndex(df.index, tz="UTC")
        status(
            f"Loaded {len(df):,} cached candles ({ist_display(df.index.min())} to "
            f"{ist_display(df.index.max())})."
        )
        return df

    status(
        f"No cache found; downloading 1h {symbol} candles from Binance "
        f"({ist_display(start)} to {ist_display(end)})."
    )
    client = Client()
    rows = client.get_historical_klines(
        symbol=symbol,
        interval=Client.KLINE_INTERVAL_1HOUR,
        start_str=start,
        end_str=end,
    )
    if not rows:
        raise RuntimeError(
            f"No Binance candles returned for {symbol} from {ist_display(start)} to {ist_display(end)}."
        )

    raw = pd.DataFrame(rows, columns=KLINE_COLUMNS)
    numeric_cols = [
        "open",
        "high",
        "low",
        "close",
        "volume",
        "quote_volume",
        "trade_count",
        "taker_buy_base_volume",
        "taker_buy_quote_volume",
    ]
    for col in numeric_cols:
        raw[col] = pd.to_numeric(raw[col], errors="coerce")
    raw["open_time"] = pd.to_datetime(raw["open_time"], unit="ms", utc=True)
    raw["close_time"] = pd.to_datetime(raw["close_time"], unit="ms", utc=True)
    df = raw.set_index("open_time").sort_index()
    df = df[
        [
            "open",
            "high",
            "low",
            "close",
            "volume",
            "quote_volume",
            "trade_count",
            "taker_buy_base_volume",
            "taker_buy_quote_volume",
            "close_time",
        ]
    ]
    df.to_csv(cache_file)
    status(f"Downloaded and cached {len(df):,} candles at {cache_file}.")
    return df


def resample_ohlcv(df: pd.DataFrame, timeframe: str) -> pd.DataFrame:
    if timeframe == "1h":
        return df.copy()
    rule = TIMEFRAME_RULES[timeframe]
    out = df.resample(rule, label="left", closed="left").agg(
        {
            "open": "first",
            "high": "max",
            "low": "min",
            "close": "last",
            "volume": "sum",
            "quote_volume": "sum",
            "trade_count": "sum",
            "taker_buy_base_volume": "sum",
            "taker_buy_quote_volume": "sum",
        }
    )
    return out.dropna()


def ema(series: pd.Series, span: int) -> pd.Series:
    return series.ewm(span=span, adjust=False, min_periods=max(2, span)).mean()


def rsi(close: pd.Series, length: int) -> pd.Series:
    diff = close.diff()
    gain = diff.clip(lower=0.0)
    loss = -diff.clip(upper=0.0)
    avg_gain = gain.ewm(alpha=1 / length, adjust=False, min_periods=length).mean()
    avg_loss = loss.ewm(alpha=1 / length, adjust=False, min_periods=length).mean()
    rs = avg_gain / avg_loss.replace(0.0, np.nan)
    return 100.0 - (100.0 / (1.0 + rs))


def atr(df: pd.DataFrame, length: int) -> pd.Series:
    prev_close = df["close"].shift(1)
    true_range = pd.concat(
        [
            df["high"] - df["low"],
            (df["high"] - prev_close).abs(),
            (df["low"] - prev_close).abs(),
        ],
        axis=1,
    ).max(axis=1)
    return true_range.ewm(alpha=1 / length, adjust=False, min_periods=length).mean()


def zscore(series: pd.Series, length: int) -> pd.Series:
    mean = series.rolling(length, min_periods=length).mean()
    std = series.rolling(length, min_periods=length).std(ddof=0)
    return (series - mean) / std.replace(0.0, np.nan)


def supertrend_direction(df: pd.DataFrame, length: int, multiplier: float) -> pd.Series:
    close = df["close"].to_numpy(dtype=float)
    high = df["high"].to_numpy(dtype=float)
    low = df["low"].to_numpy(dtype=float)
    atr_values = atr(df, length).to_numpy(dtype=float)
    hl2 = (high + low) / 2.0
    basic_upper = hl2 + multiplier * atr_values
    basic_lower = hl2 - multiplier * atr_values

    final_upper = np.full(len(df), np.nan)
    final_lower = np.full(len(df), np.nan)
    direction = np.zeros(len(df), dtype=float)

    for i in range(len(df)):
        if np.isnan(atr_values[i]):
            continue
        if i == 0 or np.isnan(final_upper[i - 1]):
            final_upper[i] = basic_upper[i]
            final_lower[i] = basic_lower[i]
            direction[i] = 0.0
            continue

        final_upper[i] = (
            basic_upper[i]
            if basic_upper[i] < final_upper[i - 1] or close[i - 1] > final_upper[i - 1]
            else final_upper[i - 1]
        )
        final_lower[i] = (
            basic_lower[i]
            if basic_lower[i] > final_lower[i - 1] or close[i - 1] < final_lower[i - 1]
            else final_lower[i - 1]
        )

        if close[i] > final_upper[i - 1]:
            direction[i] = 1.0
        elif close[i] < final_lower[i - 1]:
            direction[i] = -1.0
        else:
            direction[i] = direction[i - 1]

    return pd.Series(direction, index=df.index, name="supertrend")


def apply_risk_overlay(df: pd.DataFrame, signal: pd.Series, cfg: dict[str, Any]) -> pd.Series:
    signal = signal.astype(float).replace([np.inf, -np.inf], np.nan).fillna(0.0)
    vol_target = float(cfg.get("vol_target", 0.0))
    if vol_target > 0:
        lookback = int(cfg.get("vol_lookback", 48))
        bars_per_year = bars_per_year_for_timeframe(cfg["timeframe"])
        realized = df["close"].pct_change().rolling(lookback, min_periods=lookback).std()
        annualized = realized * math.sqrt(bars_per_year)
        scale = (vol_target / annualized.replace(0.0, np.nan)).clip(0.0, float(cfg.get("max_unit", 1.0)))
        signal = signal * scale.fillna(0.0)

    atr_limit = float(cfg.get("max_atr_pct", 0.0))
    if atr_limit > 0:
        atr_pct = atr(df, int(cfg.get("atr_len", 14))) / df["close"]
        signal = signal.where(atr_pct <= atr_limit, 0.0)

    return signal.clip(-1.0, 1.0)


def signal_buy_hold(df: pd.DataFrame, cfg: dict[str, Any]) -> pd.Series:
    return pd.Series(1.0, index=df.index)


def signal_ema_momentum(df: pd.DataFrame, cfg: dict[str, Any]) -> pd.Series:
    close = df["close"]
    fast = ema(close, int(cfg["fast"]))
    slow = ema(close, int(cfg["slow"]))
    anchor = ema(close, int(cfg["anchor"]))
    rsi_value = rsi(close, int(cfg["rsi_len"]))
    macd = ema(close, int(cfg["macd_fast"])) - ema(close, int(cfg["macd_slow"]))
    macd_signal = ema(macd, int(cfg["macd_signal"]))
    hist = macd - macd_signal

    long_rule = (
        (fast > slow)
        & (close > anchor)
        & (hist > 0)
        & (rsi_value >= float(cfg["long_rsi"]))
    )
    short_rule = (
        (fast < slow)
        & (close < anchor)
        & (hist < 0)
        & (rsi_value <= float(cfg["short_rsi"]))
    )
    signal = pd.Series(0.0, index=df.index)
    signal[long_rule] = 1.0
    signal[short_rule] = -1.0
    if cfg.get("hold", False):
        signal = signal.replace(0.0, np.nan).ffill().fillna(0.0)
    return apply_risk_overlay(df, signal, cfg)


def signal_donchian(df: pd.DataFrame, cfg: dict[str, Any]) -> pd.Series:
    entry = int(cfg["entry"])
    exit_len = int(cfg["exit"])
    close = df["close"]
    high_break = df["high"].rolling(entry, min_periods=entry).max().shift(1)
    low_break = df["low"].rolling(entry, min_periods=entry).min().shift(1)
    long_exit = df["low"].rolling(exit_len, min_periods=exit_len).min().shift(1)
    short_exit = df["high"].rolling(exit_len, min_periods=exit_len).max().shift(1)
    anchor_len = int(cfg.get("anchor", 0))
    anchor = ema(close, anchor_len) if anchor_len > 0 else pd.Series(close, index=df.index)

    state = np.zeros(len(df), dtype=float)
    for i in range(1, len(df)):
        state[i] = state[i - 1]
        if close.iloc[i] > high_break.iloc[i] and (anchor_len == 0 or close.iloc[i] > anchor.iloc[i]):
            state[i] = 1.0
        elif close.iloc[i] < low_break.iloc[i] and (anchor_len == 0 or close.iloc[i] < anchor.iloc[i]):
            state[i] = -1.0
        elif state[i] > 0 and close.iloc[i] < long_exit.iloc[i]:
            state[i] = 0.0
        elif state[i] < 0 and close.iloc[i] > short_exit.iloc[i]:
            state[i] = 0.0
    signal = pd.Series(state, index=df.index)
    return apply_risk_overlay(df, signal, cfg)


def signal_supertrend(df: pd.DataFrame, cfg: dict[str, Any]) -> pd.Series:
    direction = supertrend_direction(df, int(cfg["atr_len"]), float(cfg["multiplier"]))
    anchor_len = int(cfg.get("anchor", 0))
    if anchor_len > 0:
        anchor = ema(df["close"], anchor_len)
        direction = direction.where(
            ((direction > 0) & (df["close"] > anchor)) | ((direction < 0) & (df["close"] < anchor)),
            0.0,
        )
    return apply_risk_overlay(df, direction, cfg)


def signal_mean_reversion(df: pd.DataFrame, cfg: dict[str, Any]) -> pd.Series:
    close = df["close"]
    anchor = ema(close, int(cfg["anchor"]))
    spread = close / anchor - 1.0
    z = zscore(spread, int(cfg["z_len"]))
    trend = ema(close, int(cfg["trend_fast"])) > ema(close, int(cfg["trend_slow"]))
    entry_z = float(cfg["entry_z"])
    exit_z = float(cfg["exit_z"])

    state = np.zeros(len(df), dtype=float)
    for i in range(1, len(df)):
        state[i] = state[i - 1]
        if trend.iloc[i] and z.iloc[i] < -entry_z:
            state[i] = 1.0
        elif (not trend.iloc[i]) and z.iloc[i] > entry_z:
            state[i] = -1.0
        elif state[i] > 0 and z.iloc[i] > -exit_z:
            state[i] = 0.0
        elif state[i] < 0 and z.iloc[i] < exit_z:
            state[i] = 0.0
    signal = pd.Series(state, index=df.index)
    return apply_risk_overlay(df, signal, cfg)


def signal_ensemble(df: pd.DataFrame, cfg: dict[str, Any]) -> pd.Series:
    ema_cfg = {
        **cfg,
        "fast": cfg["fast"],
        "slow": cfg["slow"],
        "anchor": cfg["anchor"],
        "rsi_len": cfg["rsi_len"],
        "long_rsi": cfg["long_rsi"],
        "short_rsi": cfg["short_rsi"],
        "macd_fast": cfg["macd_fast"],
        "macd_slow": cfg["macd_slow"],
        "macd_signal": cfg["macd_signal"],
        "hold": False,
        "vol_target": 0.0,
        "max_atr_pct": 0.0,
    }
    don_cfg = {
        **cfg,
        "entry": cfg["entry"],
        "exit": cfg["exit"],
        "anchor": cfg["anchor"],
        "vol_target": 0.0,
        "max_atr_pct": 0.0,
    }
    st_cfg = {
        **cfg,
        "atr_len": cfg["atr_len"],
        "multiplier": cfg["multiplier"],
        "anchor": cfg["anchor"],
        "vol_target": 0.0,
        "max_atr_pct": 0.0,
    }
    votes = pd.concat(
        [
            np.sign(signal_ema_momentum(df, ema_cfg)),
            np.sign(signal_donchian(df, don_cfg)),
            np.sign(signal_supertrend(df, st_cfg)),
        ],
        axis=1,
    ).sum(axis=1)
    threshold = int(cfg.get("vote_threshold", 2))
    signal = pd.Series(0.0, index=df.index)
    signal[votes >= threshold] = 1.0
    signal[votes <= -threshold] = -1.0
    if cfg.get("hold", False):
        signal = signal.replace(0.0, np.nan).ffill().fillna(0.0)
    return apply_risk_overlay(df, signal, cfg)


SIGNAL_BUILDERS = {
    "buy_hold": signal_buy_hold,
    "ema_momentum": signal_ema_momentum,
    "donchian": signal_donchian,
    "supertrend": signal_supertrend,
    "mean_reversion": signal_mean_reversion,
    "ensemble": signal_ensemble,
}


def build_signal(df: pd.DataFrame, cfg: dict[str, Any]) -> pd.Series:
    signal = SIGNAL_BUILDERS[cfg["strategy"]](df, cfg)
    signal = signal.reindex(df.index).replace([np.inf, -np.inf], np.nan).fillna(0.0)
    warmup = int(cfg.get("warmup", 0))
    if warmup > 0:
        signal.iloc[:warmup] = 0.0
    return signal.clip(-1.0, 1.0)


def bars_per_year_for_timeframe(timeframe: str) -> float:
    hours = int(timeframe.replace("h", ""))
    return 24.0 * 365.25 / hours


def cycle_returns(
    equity: pd.Series,
    start: str,
    end: str,
    initial_equity: float = 1.0,
) -> list[dict[str, Any]]:
    """Return full two-month returns, including each cycle's first bar.

    ``equity`` is recorded after each bar return.  Therefore the first value
    inside a cycle is already *after* that cycle's first bar and must not be
    used as the denominator.  The previous cycle's final equity (or the
    account's initial equity for the first cycle) is the correct base.
    """
    start_ts = utc_timestamp(start)
    end_ts = utc_timestamp(end)
    cycles: list[dict[str, Any]] = []
    left = start_ts
    cycle_start_equity = float(initial_equity)
    while left < end_ts:
        right = min(left + pd.DateOffset(months=2), end_ts)
        window = equity[(equity.index >= left) & (equity.index < right)]
        if len(window) >= 2:
            ret = (window.iloc[-1] / cycle_start_equity) - 1.0 if cycle_start_equity > 0 else -1.0
            cycles.append(
                {
                    "start": ist_iso(left),
                    "end": ist_iso(right),
                    "return_pct": float(ret * 100.0),
                    "positive": bool(ret > 0.0),
                }
            )
            cycle_start_equity = float(window.iloc[-1])
        left = right
    return cycles


def max_drawdown(equity: pd.Series) -> float:
    running_max = equity.cummax()
    drawdown = equity / running_max - 1.0
    return float(drawdown.min())


def build_execution_path(
    bar_returns: pd.Series,
    base_unit_position: pd.Series,
    leverage: float,
    cost_rate: float,
    start: str,
    end: str,
    profit_lock: float,
    loss_stop: float,
) -> ExecutionPath:
    """Apply costs and optional cycle controls to a pre-aligned signal."""
    if profit_lock > 0.0 or loss_stop > 0.0:
        return guarded_return_path(
            bar_returns=bar_returns,
            base_unit_position=base_unit_position,
            leverage=leverage,
            cost_rate=cost_rate,
            start=start,
            end=end,
            profit_lock=profit_lock,
            loss_stop=loss_stop,
        )

    position = base_unit_position * leverage
    turnover = position.diff().abs().fillna(position.abs())
    costs = turnover * cost_rate
    strategy_return = (position * bar_returns) - costs
    gross = 1.0 + strategy_return
    blown_up = bool((gross <= 0.0).any())
    if blown_up:
        first_bad = gross.index[gross <= 0.0][0]
        gross = gross.copy()
        gross.loc[first_bad:] = 0.0
    equity = gross.cumprod()
    if blown_up:
        equity.loc[first_bad:] = 0.0
    return ExecutionPath(
        returns=strategy_return.rename("return"),
        unit_position=base_unit_position.rename("unit_position"),
        equity=equity.rename("equity"),
        blown_up=blown_up,
        exit_reason=pd.Series("", index=base_unit_position.index, dtype="object"),
    )


def prepare_backtest_inputs(
    df: pd.DataFrame,
    signal: pd.Series,
    start: str,
    end: str,
) -> tuple[pd.Series, pd.Series]:
    """Align a completed-candle signal with the following candle's return.

    Candles are indexed by their opening time.  A signal calculated from a
    candle's close is shifted one bar, so an entry/exit happens at that close
    (equivalently, the following candle's open under the close-fill model).
    High and low wicks are never used as execution prices.
    """
    close = df["close"].astype(float)
    one_bar_return = close.pct_change().fillna(0.0)
    unit_position = signal.shift(1).reindex(df.index).fillna(0.0).clip(-1.0, 1.0)

    start_ts = utc_timestamp(start)
    end_ts = utc_timestamp(end)
    eval_mask = (one_bar_return.index >= start_ts) & (one_bar_return.index < end_ts)
    one_bar_return = one_bar_return.loc[eval_mask]
    unit_position = unit_position.loc[one_bar_return.index]
    if one_bar_return.empty:
        raise RuntimeError("No candles inside the requested evaluation window.")
    return one_bar_return, unit_position


def backtest(
    df: pd.DataFrame,
    signal: pd.Series,
    leverage: float,
    fee_rate: float,
    slippage_rate: float,
    start: str,
    end: str,
    timeframe: str,
    cycle_profit_lock_pct: float = 0.0,
    cycle_loss_stop_pct: float = 0.0,
) -> tuple[Metrics, pd.Series, pd.Series, list[dict[str, Any]]]:
    one_bar_return, unit_position = prepare_backtest_inputs(df, signal, start, end)

    cost_rate = fee_rate + slippage_rate
    profit_lock = cycle_profit_lock_pct / 100.0
    loss_stop = cycle_loss_stop_pct / 100.0
    path = build_execution_path(
        bar_returns=one_bar_return,
        base_unit_position=unit_position,
        leverage=float(leverage),
        cost_rate=cost_rate,
        start=start,
        end=end,
        profit_lock=profit_lock,
        loss_stop=loss_stop,
    )

    strategy_return = path.returns
    unit_position = path.unit_position
    equity = path.equity
    blown_up = path.blown_up

    cycles = cycle_returns(equity, start, end)
    cycle_values = [c["return_pct"] for c in cycles]
    positive_cycles = sum(1 for c in cycles if c["positive"])
    final_equity = float(equity.iloc[-1])
    total_return_pct = (final_equity - 1.0) * 100.0
    years = max((equity.index[-1] - equity.index[0]).total_seconds() / (365.25 * 24 * 3600), 1e-9)
    cagr_pct = ((final_equity ** (1.0 / years)) - 1.0) * 100.0 if final_equity > 0 else -100.0
    periods = bars_per_year_for_timeframe(timeframe)
    ret_std = strategy_return.std(ddof=0)
    sharpe_like = float(strategy_return.mean() / ret_std * math.sqrt(periods)) if ret_std > 0 else 0.0
    trades = int((unit_position.diff().abs().fillna(unit_position.abs()) > 0.01).sum())
    exposure_pct = float((unit_position.abs() > 0.01).mean() * 100.0)
    metrics = Metrics(
        total_return_pct=float(total_return_pct),
        final_equity=final_equity,
        cagr_pct=float(cagr_pct),
        max_drawdown_pct=max_drawdown(equity) * 100.0,
        sharpe_like=sharpe_like,
        trades=trades,
        exposure_pct=exposure_pct,
        cycle_count=len(cycles),
        positive_cycles=positive_cycles,
        min_cycle_return_pct=float(min(cycle_values) if cycle_values else 0.0),
        avg_cycle_return_pct=float(np.mean(cycle_values) if cycle_values else 0.0),
        blown_up=blown_up,
    )
    return metrics, equity, strategy_return, cycles


def guarded_return_path(
    bar_returns: pd.Series,
    base_unit_position: pd.Series,
    leverage: float,
    cost_rate: float,
    start: str,
    end: str,
    profit_lock: float,
    loss_stop: float,
) -> ExecutionPath:
    start_ts = utc_timestamp(start)
    end_ts = utc_timestamp(end)
    cycle_left = start_ts
    cycle_right = min(cycle_left + pd.DateOffset(months=2), end_ts)
    cycle_start_equity = 1.0
    locked = False
    lock_reason = ""
    prev_position = 0.0
    equity_value = 1.0
    blown_up = False

    realized_returns: list[float] = []
    actual_units: list[float] = []
    equity_values: list[float] = []
    exit_reasons: list[str] = []

    for ts, pct_change in bar_returns.items():
        boundary_exit_reason = ""
        while ts >= cycle_right and cycle_right < end_ts:
            # If the target was reached on the final candle of a cycle, the
            # flattening order is still due at this boundary.  Preserve it for
            # this rebalance before starting to trade the new cycle.
            if locked and prev_position != 0.0:
                boundary_exit_reason = lock_reason
            cycle_left = cycle_right
            cycle_right = min(cycle_left + pd.DateOffset(months=2), end_ts)
            cycle_start_equity = max(equity_value, 1e-12)
            locked = False
            lock_reason = ""

        desired_unit = 0.0 if boundary_exit_reason or locked or blown_up else float(base_unit_position.loc[ts])
        desired_position = desired_unit * leverage
        turnover = abs(desired_position - prev_position)
        exit_reason = (
            boundary_exit_reason
            or (lock_reason if locked and prev_position != 0.0 and desired_position == 0.0 else "")
        )
        step_return = desired_position * float(pct_change) - turnover * cost_rate

        if 1.0 + step_return <= 0.0:
            blown_up = True
            equity_value = 0.0
            step_return = -1.0
        else:
            equity_value *= 1.0 + step_return

        cycle_return = equity_value / cycle_start_equity - 1.0 if cycle_start_equity > 0.0 else -1.0
        # The position is flattened on the next rebalance.  Require the target
        # to survive that known exit cost, otherwise a "20% lock" can finish
        # below 20% solely because of the closing transaction.
        next_exit_cost = abs(desired_position) * cost_rate
        cycle_return_after_exit = (
            equity_value * (1.0 - next_exit_cost) / cycle_start_equity - 1.0
            if cycle_start_equity > 0.0
            else -1.0
        )
        if profit_lock > 0.0 and cycle_return_after_exit >= profit_lock:
            locked = True
            lock_reason = "cycle_profit_lock"
        if loss_stop > 0.0 and cycle_return <= -loss_stop:
            locked = True
            lock_reason = "cycle_loss_stop"

        realized_returns.append(float(step_return))
        actual_units.append(float(desired_unit))
        equity_values.append(float(equity_value))
        exit_reasons.append(exit_reason)
        prev_position = desired_position

    index = bar_returns.index
    return ExecutionPath(
        returns=pd.Series(realized_returns, index=index, name="return"),
        unit_position=pd.Series(actual_units, index=index, name="unit_position"),
        equity=pd.Series(equity_values, index=index, name="equity"),
        blown_up=blown_up,
        exit_reason=pd.Series(exit_reasons, index=index, name="exit_reason", dtype="object"),
    )


TRADE_COLUMNS = [
    "symbol",
    "entry_time",
    "exit_time",
    "direction",
    "entry_price",
    "exit_price",
    "net_pnl",
    "ret_pct",
    "duration_h",
    "leverage",
    "reason",
]


def build_trade_log(
    df: pd.DataFrame,
    path: ExecutionPath,
    leverage: float,
    cost_rate: float,
    symbol: str,
    timeframe: str,
) -> pd.DataFrame:
    """Build one round-trip row per continuous long or short position.

    The backtester normalizes initial account equity to 1.0.  ``net_pnl`` is
    therefore denominated in those initial-equity units; multiply it by a live
    account's starting USDT balance to obtain a corresponding USDT amount.
    Resizes in the same direction remain part of one trade and their turnover
    costs are included in that trade's P&L.
    """
    positions = (path.unit_position * float(leverage)).astype(float)
    previous_close = df["close"].astype(float).shift(1).reindex(positions.index)
    bar_close = df["close"].astype(float).reindex(positions.index)
    market_returns = df["close"].astype(float).pct_change().fillna(0.0).reindex(positions.index)
    strategy_returns = path.returns.reindex(positions.index).astype(float)
    exit_reasons = path.exit_reason.reindex(positions.index).fillna("").astype(str)
    bar_hours = int(timeframe.replace("h", ""))
    bar_length = pd.Timedelta(hours=bar_hours)

    rows: list[dict[str, Any]] = []
    active: dict[str, Any] | None = None
    equity_value = 1.0
    previous_position = 0.0

    def fill_price(ts: pd.Timestamp) -> float:
        price = previous_close.loc[ts]
        if pd.isna(price):
            price = df.loc[ts, "open"]
        return float(price)

    def open_trade(ts: pd.Timestamp, position: float, price: float, entry_cost: float) -> None:
        nonlocal active
        active = {
            "entry_time": ts,
            "direction": "long" if position > 0.0 else "short",
            "entry_price": price,
            "entry_equity": equity_value,
            "net_pnl": -(equity_value * entry_cost),
        }

    def close_trade(ts: pd.Timestamp, price: float, reason: str, exit_cost: float) -> None:
        nonlocal active
        if active is None:
            return
        active["net_pnl"] -= equity_value * exit_cost
        entry_time = active["entry_time"]
        entry_equity = float(active["entry_equity"])
        net_pnl = float(active["net_pnl"])
        rows.append(
            {
                "symbol": symbol,
                "entry_time": ist_iso(entry_time),
                "exit_time": ist_iso(ts),
                "direction": active["direction"],
                "entry_price": float(active["entry_price"]),
                "exit_price": float(price),
                "net_pnl": net_pnl,
                "ret_pct": (net_pnl / entry_equity * 100.0) if entry_equity > 0.0 else -100.0,
                "duration_h": (ts - entry_time).total_seconds() / 3600.0,
                "leverage": float(leverage),
                "reason": reason,
            }
        )
        active = None

    for ts, position in positions.items():
        position = float(position)
        previous_sign = int(np.sign(previous_position))
        current_sign = int(np.sign(position))
        price = fill_price(ts)
        turnover_cost = abs(position - previous_position) * cost_rate

        if previous_sign != 0 and current_sign != previous_sign:
            reason = exit_reasons.loc[ts] or ("signal_reversal" if current_sign else "signal_exit")
            close_trade(ts, price, reason, abs(previous_position) * cost_rate)

        if current_sign != 0 and current_sign != previous_sign:
            open_trade(ts, position, price, abs(position) * cost_rate)
        elif current_sign != 0 and active is not None:
            # A same-direction volatility resize is part of the existing trade.
            active["net_pnl"] -= equity_value * turnover_cost

        if current_sign != 0 and active is not None:
            active["net_pnl"] += equity_value * position * float(market_returns.loc[ts])

        gross = 1.0 + float(strategy_returns.loc[ts])
        equity_value = 0.0 if gross <= 0.0 else equity_value * gross
        previous_position = position

    if active is not None:
        last_ts = positions.index[-1]
        # A position still open at the sample end is marked at the last close;
        # no invented closing fee is added because the strategy never placed
        # that exit order during the backtest.
        close_trade(last_ts + bar_length, float(bar_close.loc[last_ts]), "backtest_end_mark", 0.0)

    return pd.DataFrame(rows, columns=TRADE_COLUMNS)


def write_trades_csv(trades: pd.DataFrame, path: Path = REPORT_DIR / "trades.csv") -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    trades.reindex(columns=TRADE_COLUMNS).to_csv(path, index=False)


def equity_chart_svg(equity: pd.Series, width: int = 900, height: int = 280) -> str:
    """Return a compact, dependency-free SVG chart for the HTML report."""
    values = equity.astype(float).to_numpy()
    if len(values) == 0:
        return ""
    minimum = float(np.min(values))
    maximum = float(np.max(values))
    padding = 28
    plot_width = width - (2 * padding)
    plot_height = height - (2 * padding)
    value_range = maximum - minimum
    if value_range <= 0.0:
        value_range = 1.0
    denominator = max(len(values) - 1, 1)
    points = " ".join(
        f"{padding + (idx / denominator) * plot_width:.2f},"
        f"{height - padding - ((value - minimum) / value_range) * plot_height:.2f}"
        for idx, value in enumerate(values)
    )
    return f"""<svg viewBox=\"0 0 {width} {height}\" role=\"img\" aria-label=\"Equity curve\">
  <rect x=\"0\" y=\"0\" width=\"{width}\" height=\"{height}\" rx=\"8\" fill=\"#101827\" />
  <line x1=\"{padding}\" y1=\"{height - padding}\" x2=\"{width - padding}\" y2=\"{height - padding}\" stroke=\"#40516b\" />
  <line x1=\"{padding}\" y1=\"{padding}\" x2=\"{padding}\" y2=\"{height - padding}\" stroke=\"#40516b\" />
  <polyline fill=\"none\" stroke=\"#4ade80\" stroke-width=\"2\" points=\"{points}\" />
  <text x=\"{padding}\" y=\"18\" fill=\"#cbd5e1\" font-size=\"13\">Peak: {maximum:.4f}x</text>
  <text x=\"{padding}\" y=\"{height - 8}\" fill=\"#cbd5e1\" font-size=\"13\">Start (IST): {ist_timestamp(equity.index[0]).date()}</text>
  <text x=\"{width - 150}\" y=\"{height - 8}\" fill=\"#cbd5e1\" font-size=\"13\">End (IST): {ist_timestamp(equity.index[-1]).date()}</text>
</svg>"""


def write_backtest_run_reports(
    payload: dict[str, Any],
    metrics: Metrics,
    equity: pd.Series,
    cycles: list[dict[str, Any]],
    trades: pd.DataFrame,
) -> dict[str, Path]:
    """Write reports for a direct ``backtest`` command without overwriting optimization outputs."""
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    paths = {
        "trades": REPORT_DIR / "trades.csv",
        "equity": REPORT_DIR / "backtest_equity_curve.csv",
        "cycles": REPORT_DIR / "backtest_bimonthly_cycles.csv",
        "summary_csv": REPORT_DIR / "backtest_report.csv",
        "markdown": REPORT_DIR / "backtest_report.md",
        "html": REPORT_DIR / "backtest_report.html",
    }

    write_trades_csv(trades, paths["trades"])
    ist_indexed(equity.rename("equity")).rename_axis("open_time").to_csv(paths["equity"])
    pd.DataFrame(cycles, columns=["start", "end", "return_pct", "positive"]).to_csv(paths["cycles"], index=False)

    trade_count = len(trades)
    winning_trades = int((trades["net_pnl"] > 0.0).sum()) if trade_count else 0
    win_rate = (winning_trades / trade_count * 100.0) if trade_count else 0.0
    normalized_trade_pnl = float(trades["net_pnl"].sum()) if trade_count else 0.0
    summary_rows = [
        ("backtest", "symbol", payload["symbol"]),
        ("backtest", "start_ist", ist_display(payload["start"])),
        ("backtest", "end_ist", ist_display(payload["end"])),
        ("configuration", "strategy", payload["config"]["strategy"]),
        ("configuration", "timeframe", payload["timeframe"]),
        ("configuration", "leverage", float(payload["leverage"])),
        ("configuration", "fee_bps", float(payload["fee_bps"])),
        ("configuration", "slippage_bps", float(payload["slippage_bps"])),
        ("performance", "total_return_pct", metrics.total_return_pct),
        ("performance", "final_equity_multiple", metrics.final_equity),
        ("performance", "cagr_pct", metrics.cagr_pct),
        ("performance", "max_drawdown_pct", metrics.max_drawdown_pct),
        ("performance", "sharpe_like", metrics.sharpe_like),
        ("performance", "exposure_pct", metrics.exposure_pct),
        ("performance", "positive_cycles", f"{metrics.positive_cycles}/{metrics.cycle_count}"),
        ("performance", "worst_cycle_return_pct", metrics.min_cycle_return_pct),
        ("trades", "round_trip_count", trade_count),
        ("trades", "winning_round_trips", winning_trades),
        ("trades", "win_rate_pct", win_rate),
        ("trades", "net_pnl_initial_equity_units", normalized_trade_pnl),
    ]
    pd.DataFrame(summary_rows, columns=["section", "metric", "value"]).to_csv(paths["summary_csv"], index=False)

    metric_lines = [
        ("Total return", f"{metrics.total_return_pct:.2f}%"),
        ("Final equity multiple", f"{metrics.final_equity:.4f}x"),
        ("CAGR", f"{metrics.cagr_pct:.2f}%"),
        ("Max drawdown", f"{metrics.max_drawdown_pct:.2f}%"),
        ("Sharpe-like", f"{metrics.sharpe_like:.3f}"),
        ("Exposure", f"{metrics.exposure_pct:.2f}%"),
        ("Positive cycles", f"{metrics.positive_cycles}/{metrics.cycle_count}"),
        ("Worst cycle", f"{metrics.min_cycle_return_pct:.2f}%"),
        ("Round-trip trades", str(trade_count)),
        ("Trade win rate", f"{win_rate:.2f}%"),
    ]
    cycle_markdown = "\n".join(
        f"| {cycle['start'][:10]} | {cycle['end'][:10]} | {cycle['return_pct']:.2f}% | "
        f"{'yes' if cycle['positive'] else 'no'} |"
        for cycle in cycles
    )
    metric_markdown = "\n".join(f"| {name} | {value} |" for name, value in metric_lines)
    report_md = f"""# {payload['symbol']} Backtest Run

Period: {ist_display(payload['start'])} to {ist_display(payload['end'])}  
Strategy: {payload['config']['strategy']} on {payload['timeframe']} candles at {float(payload['leverage']):g}x leverage

## Performance

| Metric | Value |
|---|---:|
{metric_markdown}

## Configuration

```json
{json.dumps(payload['config'], indent=2)}
```

## Bimonthly Cycles

| Start | End | Return | Positive |
|---|---:|---:|---:|
{cycle_markdown}

## Generated Files

- `reports/trades.csv`
- `reports/backtest_equity_curve.csv`
- `reports/backtest_bimonthly_cycles.csv`
- `reports/backtest_report.csv`
- `reports/backtest_report.html`

`net_pnl` in `trades.csv` uses the backtest's normalized starting equity of 1.0.
"""
    paths["markdown"].write_text(report_md, encoding="utf-8")

    metrics_html = "".join(
        f"<tr><th>{html.escape(name)}</th><td>{html.escape(value)}</td></tr>" for name, value in metric_lines
    )
    cycle_html = "".join(
        "<tr>"
        f"<td>{html.escape(cycle['start'][:10])}</td>"
        f"<td>{html.escape(cycle['end'][:10])}</td>"
        f"<td>{cycle['return_pct']:.2f}%</td>"
        f"<td>{'Yes' if cycle['positive'] else 'No'}</td>"
        "</tr>"
        for cycle in cycles
    )
    config_html = html.escape(json.dumps(payload["config"], indent=2))
    report_html = f"""<!doctype html>
<html lang=\"en\">
<head>
  <meta charset=\"utf-8\">
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
  <title>{html.escape(payload['symbol'])} backtest report</title>
  <style>
    :root {{ color-scheme: dark; font-family: Inter, Segoe UI, sans-serif; }}
    body {{ margin: 0; background: #0b1120; color: #e2e8f0; }}
    main {{ max-width: 980px; margin: 0 auto; padding: 32px 20px 48px; }}
    h1, h2 {{ color: #f8fafc; }}
    .subtle {{ color: #94a3b8; }}
    .grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 14px; }}
    .card, pre, table {{ background: #101827; border: 1px solid #263449; border-radius: 8px; }}
    .card {{ padding: 16px; }}
    .label {{ color: #94a3b8; font-size: 13px; }}
    .value {{ font-size: 23px; font-weight: 700; margin-top: 5px; }}
    table {{ border-collapse: collapse; width: 100%; overflow: hidden; }}
    th, td {{ padding: 9px 12px; border-bottom: 1px solid #263449; text-align: left; }}
    th {{ color: #cbd5e1; }}
    td {{ color: #e2e8f0; }}
    pre {{ padding: 14px; overflow-x: auto; }}
    a {{ color: #86efac; }}
    .chart {{ width: 100%; overflow-x: auto; }}
  </style>
</head>
<body>
  <main>
    <h1>{html.escape(payload['symbol'])} Backtest Run</h1>
    <p class=\"subtle\">{html.escape(ist_display(payload['start']))} to {html.escape(ist_display(payload['end']))} | {html.escape(payload['config']['strategy'])} | {html.escape(payload['timeframe'])} | {float(payload['leverage']):g}x leverage</p>
    <div class=\"grid\">
      <div class=\"card\"><div class=\"label\">Total return</div><div class=\"value\">{metrics.total_return_pct:.2f}%</div></div>
      <div class=\"card\"><div class=\"label\">Final equity</div><div class=\"value\">{metrics.final_equity:.4f}x</div></div>
      <div class=\"card\"><div class=\"label\">Max drawdown</div><div class=\"value\">{metrics.max_drawdown_pct:.2f}%</div></div>
      <div class=\"card\"><div class=\"label\">Round-trip trades</div><div class=\"value\">{trade_count}</div></div>
    </div>
    <h2>Equity curve</h2>
    <div class=\"chart\">{equity_chart_svg(equity)}</div>
    <h2>Performance</h2>
    <table>{metrics_html}</table>
    <h2>Bimonthly cycles</h2>
    <table><thead><tr><th>Start</th><th>End</th><th>Return</th><th>Positive</th></tr></thead><tbody>{cycle_html}</tbody></table>
    <h2>Configuration</h2>
    <pre>{config_html}</pre>
    <p class=\"subtle\">Detailed data: <a href=\"trades.csv\">trades.csv</a>, <a href=\"backtest_equity_curve.csv\">equity curve CSV</a>, <a href=\"backtest_bimonthly_cycles.csv\">cycles CSV</a>, <a href=\"backtest_report.csv\">summary CSV</a>.</p>
  </main>
</body>
</html>
"""
    paths["html"].write_text(report_html, encoding="utf-8")
    return paths


def base_candidate_configs() -> Iterable[dict[str, Any]]:
    for timeframe in TIMEFRAME_RULES:
        yield {
            "strategy": "buy_hold",
            "timeframe": timeframe,
            "warmup": 0,
            "vol_target": 0.0,
            "max_atr_pct": 0.0,
            "cycle_profit_lock_pct": 0.0,
            "cycle_loss_stop_pct": 0.0,
        }


def random_candidate_configs(max_candidates: int, seed: int) -> Iterable[dict[str, Any]]:
    rng = random.Random(seed)
    timeframes = list(TIMEFRAME_RULES)
    strategies = ["ema_momentum", "donchian", "supertrend", "mean_reversion", "ensemble"]

    for _ in range(max_candidates):
        timeframe = rng.choice(timeframes)
        strategy = rng.choice(strategies)
        cfg: dict[str, Any] = {
            "strategy": strategy,
            "timeframe": timeframe,
            "vol_target": rng.choice([0.0, 0.35, 0.5, 0.7, 0.9, 1.2]),
            "vol_lookback": rng.choice([24, 36, 48, 72, 96, 144]),
            "max_unit": rng.choice([0.75, 1.0, 1.25]),
            "max_atr_pct": rng.choice([0.0, 0.025, 0.035, 0.05, 0.075]),
            "atr_len": rng.choice([7, 10, 14, 21, 28, 34]),
            "cycle_profit_lock_pct": rng.choice([0.0, 0.0, 0.0, 5.0, 8.0, 12.0, 15.0, 20.0, 30.0]),
            "cycle_loss_stop_pct": rng.choice([0.0, 0.0, 0.0, 4.0, 7.0, 10.0, 15.0]),
        }

        if strategy == "ema_momentum":
            fast = rng.choice([5, 8, 10, 12, 16, 21, 34, 55])
            slow = rng.choice([34, 55, 72, 89, 144, 200, 250])
            if fast >= slow:
                fast, slow = min(fast, slow // 2), max(fast, slow)
            cfg.update(
                {
                    "fast": fast,
                    "slow": slow,
                    "anchor": rng.choice([89, 144, 200, 250, 300, 400]),
                    "rsi_len": rng.choice([7, 10, 14, 21, 28]),
                    "long_rsi": rng.choice([45, 48, 50, 52, 55, 58]),
                    "short_rsi": rng.choice([42, 45, 48, 50, 52, 55]),
                    "macd_fast": rng.choice([8, 12, 16, 21]),
                    "macd_slow": rng.choice([21, 26, 34, 55]),
                    "macd_signal": rng.choice([5, 9, 13, 21]),
                    "hold": rng.choice([False, True]),
                    "warmup": 450,
                }
            )
        elif strategy == "donchian":
            entry = rng.choice([12, 18, 24, 36, 48, 55, 72, 96, 120, 144, 200])
            cfg.update(
                {
                    "entry": entry,
                    "exit": rng.choice([6, 9, 12, 18, 24, 36, 48, min(entry, 72)]),
                    "anchor": rng.choice([0, 89, 144, 200, 300, 400]),
                    "warmup": max(450, entry + 20),
                }
            )
        elif strategy == "supertrend":
            cfg.update(
                {
                    "atr_len": rng.choice([7, 10, 14, 21, 28, 34, 55]),
                    "multiplier": rng.choice([1.2, 1.5, 1.8, 2.0, 2.4, 2.8, 3.2, 3.8, 4.5]),
                    "anchor": rng.choice([0, 89, 144, 200, 300, 400]),
                    "warmup": 450,
                }
            )
        elif strategy == "mean_reversion":
            trend_fast = rng.choice([24, 36, 48, 72, 96])
            trend_slow = rng.choice([144, 200, 250, 300, 400])
            if trend_fast >= trend_slow:
                trend_fast = max(8, trend_slow // 3)
            cfg.update(
                {
                    "anchor": rng.choice([34, 55, 72, 96, 144, 200]),
                    "z_len": rng.choice([24, 36, 48, 72, 96, 144]),
                    "entry_z": rng.choice([0.7, 1.0, 1.25, 1.5, 1.75, 2.0]),
                    "exit_z": rng.choice([0.0, 0.15, 0.3, 0.5]),
                    "trend_fast": trend_fast,
                    "trend_slow": trend_slow,
                    "warmup": 450,
                }
            )
        elif strategy == "ensemble":
            fast = rng.choice([8, 12, 16, 21, 34])
            slow = rng.choice([55, 72, 89, 144, 200])
            cfg.update(
                {
                    "fast": fast,
                    "slow": slow,
                    "anchor": rng.choice([89, 144, 200, 250, 300]),
                    "rsi_len": rng.choice([10, 14, 21]),
                    "long_rsi": rng.choice([48, 50, 52, 55]),
                    "short_rsi": rng.choice([45, 48, 50, 52]),
                    "macd_fast": rng.choice([8, 12, 16]),
                    "macd_slow": rng.choice([21, 26, 34, 55]),
                    "macd_signal": rng.choice([5, 9, 13]),
                    "entry": rng.choice([18, 24, 36, 48, 55, 72, 96]),
                    "exit": rng.choice([9, 12, 18, 24, 36, 48]),
                    "atr_len": rng.choice([7, 10, 14, 21, 28]),
                    "multiplier": rng.choice([1.5, 1.8, 2.0, 2.4, 2.8, 3.2]),
                    "vote_threshold": rng.choice([1, 2]),
                    "hold": rng.choice([False, True]),
                    "warmup": 450,
                }
            )
        yield cfg


def score_metrics(metrics: Metrics, target_profit_pct: float) -> float:
    missing_cycles = metrics.cycle_count - metrics.positive_cycles
    score = metrics.positive_cycles * 100000.0
    score += metrics.min_cycle_return_pct * 3000.0
    score += metrics.avg_cycle_return_pct * 250.0
    score += metrics.max_drawdown_pct * 20.0
    if missing_cycles:
        score -= 150000.0 * missing_cycles
        score -= 1500.0 * abs(min(0.0, metrics.min_cycle_return_pct))
        score += min(metrics.total_return_pct, target_profit_pct * 2.0) * 0.5
    else:
        score += min(metrics.total_return_pct, target_profit_pct * 3.0) * 25.0
        score += max(0.0, metrics.total_return_pct - target_profit_pct) * 2.0
    if metrics.total_return_pct < target_profit_pct and not missing_cycles:
        score -= (target_profit_pct - metrics.total_return_pct) * 5.0
    if metrics.blown_up:
        score -= 100000.0
    return float(score)


def evaluate_config(
    datasets: dict[str, pd.DataFrame],
    cfg: dict[str, Any],
    leverages: list[float],
    fee_rate: float,
    slippage_rate: float,
    start: str,
    end: str,
) -> list[dict[str, Any]]:
    df = datasets[cfg["timeframe"]]
    signal = build_signal(df, cfg)
    results = []
    for leverage in leverages:
        metrics, equity, returns, cycles = backtest(
            df=df,
            signal=signal,
            leverage=leverage,
            fee_rate=fee_rate,
            slippage_rate=slippage_rate,
            start=start,
            end=end,
            timeframe=cfg["timeframe"],
            cycle_profit_lock_pct=float(cfg.get("cycle_profit_lock_pct", 0.0)),
            cycle_loss_stop_pct=float(cfg.get("cycle_loss_stop_pct", 0.0)),
        )
        results.append(
            {
                "config": cfg,
                "leverage": leverage,
                "metrics": metrics,
                "equity": equity,
                "returns": returns,
                "cycles": cycles,
            }
        )
    return results


def optimize(args: argparse.Namespace) -> dict[str, Any]:
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    data_start = (utc_timestamp(args.start) - pd.DateOffset(days=args.warmup_days)).date().isoformat()
    status(
        f"Starting optimization for {args.symbol}: evaluation window "
        f"{ist_display(args.start)} to {ist_display(args.end)}; "
        f"using {args.warmup_days} warm-up days."
    )
    one_hour = fetch_binance_klines(args.symbol, data_start, args.end, CACHE_DIR)
    status("Preparing candle data for all supported timeframes.")
    datasets = {tf: resample_ohlcv(one_hour, tf) for tf in TIMEFRAME_RULES}
    timeframe_sizes = ", ".join(f"{tf}={len(df):,}" for tf, df in datasets.items())
    status(f"Timeframe datasets ready ({timeframe_sizes} candles).")
    leverages = [round(x, 2) for x in np.arange(args.min_leverage, args.max_leverage + 0.001, args.leverage_step)]
    fee_rate = args.fee_bps / 10000.0
    slippage_rate = args.slippage_bps / 10000.0
    target_profit_pct = args.target_profit_pct

    base_candidates = list(base_candidate_configs())
    candidates = list(base_candidates)
    candidates.extend(random_candidate_configs(args.max_candidates, args.seed))

    best: dict[str, Any] | None = None
    best_success: dict[str, Any] | None = None
    leaderboard: list[dict[str, Any]] = []
    total = len(candidates)
    status(
        f"Generated {total:,} strategy candidates ({len(base_candidates):,} base + "
        f"{args.max_candidates:,} randomized). Each will be tested at {len(leverages)} leverage levels "
        f"from {leverages[0]:g}x to {leverages[-1]:g}x."
    )

    def record_result(result: dict[str, Any]) -> None:
        nonlocal best, best_success, leaderboard
        metrics: Metrics = result["metrics"]
        score = score_metrics(metrics, target_profit_pct)
        packed = {
            "score": score,
            "config": result["config"],
            "leverage": result["leverage"],
            "metrics": metrics,
            "cycles": result["cycles"],
            "equity": result["equity"],
            "returns": result["returns"],
        }
        if best is None or score > best["score"]:
            best = packed
        success = (
            metrics.total_return_pct >= target_profit_pct
            and metrics.positive_cycles == metrics.cycle_count
            and not metrics.blown_up
        )
        if success and (best_success is None or score > best_success["score"]):
            best_success = packed
        leaderboard.append(packed)

    for idx, cfg in enumerate(candidates, start=1):
        if args.verbose:
            status(
                f"Testing candidate {idx:,}/{total:,}: {cfg['strategy']} on {cfg['timeframe']} "
                f"candles (profit lock {float(cfg.get('cycle_profit_lock_pct', 0.0)):g}%)."
            )
        try:
            results = evaluate_config(
                datasets=datasets,
                cfg=cfg,
                leverages=leverages,
                fee_rate=fee_rate,
                slippage_rate=slippage_rate,
                start=args.start,
                end=args.end,
            )
        except Exception as exc:
            status(f"Candidate {idx:,}/{total:,} failed: {cfg} -> {exc}")
            continue

        for result in results:
            record_result(result)

        if idx % max(1, args.progress_every) == 0 or idx == total:
            current = best_success or best
            if current is not None:
                m: Metrics = current["metrics"]
                label = "SUCCESS" if best_success else "best"
                status(
                    f"Search progress {idx:,}/{total:,}; current {label}: return={m.total_return_pct:.1f}% "
                    f"cycles={m.positive_cycles}/{m.cycle_count} "
                    f"min_cycle={m.min_cycle_return_pct:.2f}% "
                    f"dd={m.max_drawdown_pct:.1f}% "
                    f"lev={current['leverage']} {current['config']['strategy']} {current['config']['timeframe']}"
                )

    if best is None:
        raise RuntimeError("No candidates could be evaluated.")

    if args.refine_top > 0 and leaderboard:
        locks = [float(item) for item in args.refine_profit_locks.split(",") if item.strip()]
        seeds = sorted(leaderboard, key=lambda x: x["score"], reverse=True)[: args.refine_top]
        seen: set[str] = set()
        refinement_total = len(seeds) * len(locks)
        status(
            f"Initial search complete; refining the top {len(seeds)} candidates across "
            f"{len(locks)} profit-lock settings ({refinement_total} possible evaluations)."
        )
        refinement_idx = 0
        for seed in seeds:
            for lock in locks:
                refinement_idx += 1
                cfg = dict(seed["config"])
                cfg["cycle_profit_lock_pct"] = lock
                cfg["cycle_loss_stop_pct"] = 0.0
                key = json.dumps(cfg, sort_keys=True)
                if key in seen:
                    status(f"Refinement {refinement_idx}/{refinement_total}: duplicate configuration skipped.")
                    continue
                seen.add(key)
                status(
                    f"Refinement {refinement_idx}/{refinement_total}: testing "
                    f"{cfg['strategy']} on {cfg['timeframe']} with a {lock:g}% profit lock."
                )
                try:
                    results = evaluate_config(
                        datasets=datasets,
                        cfg=cfg,
                        leverages=leverages,
                        fee_rate=fee_rate,
                        slippage_rate=slippage_rate,
                        start=args.start,
                        end=args.end,
                    )
                except Exception as exc:
                    status(f"Refinement {refinement_idx}/{refinement_total} failed: {cfg} -> {exc}")
                    continue
                for result in results:
                    record_result(result)

    chosen = best_success or best
    leaderboard = sorted(leaderboard, key=lambda x: x["score"], reverse=True)[: args.keep_top]
    chosen_metrics: Metrics = chosen["metrics"]
    status(
        f"Search finished. Selected {chosen['config']['strategy']} on {chosen['config']['timeframe']} "
        f"at {chosen['leverage']:g}x leverage: return={chosen_metrics.total_return_pct:.1f}%, "
        f"positive cycles={chosen_metrics.positive_cycles}/{chosen_metrics.cycle_count}."
    )
    status("Writing the selected configuration, equity curve, cycle results, and summary reports.")
    write_report(
        chosen=chosen,
        leaderboard=leaderboard,
        args=args,
        success=best_success is not None,
    )
    status(f"Optimization complete. Reports are available in {REPORT_DIR}.")
    return chosen


def serializable_result(item: dict[str, Any], include_series: bool = False) -> dict[str, Any]:
    out = {
        "score": item["score"],
        "strategy": item["config"]["strategy"],
        "timeframe": item["config"]["timeframe"],
        "leverage": item["leverage"],
        "config": item["config"],
        "metrics": asdict(item["metrics"]),
        "cycles": item["cycles"],
    }
    if include_series:
        out["equity"] = [
            {"time": ist_iso(idx), "equity": float(value)}
            for idx, value in item["equity"].items()
        ]
        out["returns"] = [
            {"time": ist_iso(idx), "return": float(value)}
            for idx, value in item["returns"].items()
        ]
    return out


def write_report(
    chosen: dict[str, Any],
    leaderboard: list[dict[str, Any]],
    args: argparse.Namespace,
    success: bool,
) -> None:
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    best_json = REPORT_DIR / "best_config.json"
    summary_json = REPORT_DIR / "optimization_summary.json"
    equity_csv = REPORT_DIR / "best_equity_curve.csv"
    cycle_csv = REPORT_DIR / "best_bimonthly_cycles.csv"
    report_md = REPORT_DIR / "backtest_report.md"

    status(f"Saving equity curve to {equity_csv}.")
    ist_indexed(chosen["equity"].rename("equity")).to_csv(equity_csv)
    status(f"Saving two-month cycle results to {cycle_csv}.")
    pd.DataFrame(chosen["cycles"]).to_csv(cycle_csv, index=False)

    config_payload = {
        "symbol": args.symbol,
        "start": args.start,
        "end": args.end,
        "warmup_days": args.warmup_days,
        "fee_bps": args.fee_bps,
        "slippage_bps": args.slippage_bps,
        **serializable_result(chosen),
    }
    status(f"Saving selected strategy configuration to {best_json}.")
    best_json.write_text(json.dumps(config_payload, indent=2), encoding="utf-8")
    summary_payload = {
        "success": success,
        "target_profit_pct": args.target_profit_pct,
        "data_start": ist_display(utc_timestamp(args.start) - pd.DateOffset(days=args.warmup_days)),
        "candidate_count": args.max_candidates,
        "min_leverage": args.min_leverage,
        "max_leverage": args.max_leverage,
        "leverage_step": args.leverage_step,
        "best": serializable_result(chosen),
        "leaderboard": [serializable_result(item) for item in leaderboard],
    }
    status(f"Saving optimization leaderboard to {summary_json}.")
    summary_json.write_text(json.dumps(summary_payload, indent=2), encoding="utf-8")

    m: Metrics = chosen["metrics"]
    cycle_lines = []
    for cycle in chosen["cycles"]:
        cycle_lines.append(
            f"| {cycle['start'][:10]} | {cycle['end'][:10]} | {cycle['return_pct']:.2f}% | "
            f"{'yes' if cycle['positive'] else 'no'} |"
        )
    leader_lines = []
    for rank, item in enumerate(leaderboard[:10], start=1):
        lm: Metrics = item["metrics"]
        leader_lines.append(
            f"| {rank} | {item['config']['strategy']} | {item['config']['timeframe']} | "
            f"{item['leverage']} | {lm.total_return_pct:.1f}% | "
            f"{lm.positive_cycles}/{lm.cycle_count} | {lm.min_cycle_return_pct:.2f}% | "
            f"{lm.max_drawdown_pct:.1f}% |"
        )

    report = f"""# BTCUSDT Binance Backtest

Period: {ist_display(args.start)} to {ist_display(args.end)}

Indicator warmup data starts: {ist_display(utc_timestamp(args.start) - pd.DateOffset(days=args.warmup_days))}

Status: {"target met" if success else "target not met"}

This is an in-sample research backtest. It is useful for deciding what to test next, not proof that the strategy will work live.

## Best Candidate

- Strategy: {chosen["config"]["strategy"]}
- Candle timeframe: {chosen["config"]["timeframe"]}
- Leverage: {chosen["leverage"]}x
- Fees: {args.fee_bps:.2f} bps per notional turnover
- Slippage: {args.slippage_bps:.2f} bps per notional turnover
- Total return: {m.total_return_pct:.2f}%
- Final equity multiple: {m.final_equity:.4f}x
- CAGR: {m.cagr_pct:.2f}%
- Max drawdown: {m.max_drawdown_pct:.2f}%
- Positive bimonthly cycles: {m.positive_cycles}/{m.cycle_count}
- Worst bimonthly cycle: {m.min_cycle_return_pct:.2f}%
- Trades/position changes: {m.trades}
- Exposure: {m.exposure_pct:.2f}%

## Configuration

```json
{json.dumps(chosen["config"], indent=2)}
```

## Bimonthly Cycles

| Start | End | Return | Positive |
|---|---:|---:|---:|
{chr(10).join(cycle_lines)}

## Top Candidates

| Rank | Strategy | Timeframe | Lev | Return | Cycles | Worst Cycle | Max DD |
|---:|---|---:|---:|---:|---:|---:|---:|
{chr(10).join(leader_lines)}

## Files

- Best config: `reports/best_config.json`
- Equity curve: `reports/best_equity_curve.csv`
- Bimonthly cycles: `reports/best_bimonthly_cycles.csv`
- Optimizer summary: `reports/optimization_summary.json`
"""
    status(f"Writing readable backtest report to {report_md}.")
    report_md.write_text(report, encoding="utf-8")


def run_saved_config(args: argparse.Namespace) -> None:
    status(f"Loading saved configuration from {args.config}.")
    payload = json.loads(Path(args.config).read_text(encoding="utf-8"))
    warmup_days = int(payload.get("warmup_days", 365))
    data_start = (utc_timestamp(payload["start"]) - pd.DateOffset(days=warmup_days)).date().isoformat()
    status(
        f"Re-running {payload['config']['strategy']} on {payload['timeframe']} candles at "
        f"{float(payload['leverage']):g}x leverage."
    )
    one_hour = fetch_binance_klines(payload["symbol"], data_start, payload["end"], CACHE_DIR)
    status(f"Resampling {len(one_hour):,} 1h candles to {payload['timeframe']} candles.")
    df = resample_ohlcv(one_hour, payload["timeframe"])
    status(f"Building the saved strategy signal over {len(df):,} candles.")
    signal = build_signal(df, payload["config"])
    status("Running the backtest with fees, slippage, and cycle controls applied.")
    metrics, equity, returns, cycles = backtest(
        df=df,
        signal=signal,
        leverage=float(payload["leverage"]),
        fee_rate=float(payload["fee_bps"]) / 10000.0,
        slippage_rate=float(payload["slippage_bps"]) / 10000.0,
        start=payload["start"],
        end=payload["end"],
        timeframe=payload["timeframe"],
        cycle_profit_lock_pct=float(payload["config"].get("cycle_profit_lock_pct", 0.0)),
        cycle_loss_stop_pct=float(payload["config"].get("cycle_loss_stop_pct", 0.0)),
    )
    one_bar_return, base_unit_position = prepare_backtest_inputs(
        df=df,
        signal=signal,
        start=payload["start"],
        end=payload["end"],
    )
    execution_path = build_execution_path(
        bar_returns=one_bar_return,
        base_unit_position=base_unit_position,
        leverage=float(payload["leverage"]),
        cost_rate=(float(payload["fee_bps"]) + float(payload["slippage_bps"])) / 10000.0,
        start=payload["start"],
        end=payload["end"],
        profit_lock=float(payload["config"].get("cycle_profit_lock_pct", 0.0)) / 100.0,
        loss_stop=float(payload["config"].get("cycle_loss_stop_pct", 0.0)) / 100.0,
    )
    trades = build_trade_log(
        df=df,
        path=execution_path,
        leverage=float(payload["leverage"]),
        cost_rate=(float(payload["fee_bps"]) + float(payload["slippage_bps"])) / 10000.0,
        symbol=payload["symbol"],
        timeframe=payload["timeframe"],
    )
    report_paths = write_backtest_run_reports(
        payload=payload,
        metrics=metrics,
        equity=equity,
        cycles=cycles,
        trades=trades,
    )
    status(
        f"Backtest complete: return={metrics.total_return_pct:.1f}%, "
        f"max drawdown={metrics.max_drawdown_pct:.1f}%, trades={metrics.trades}. "
        f"Wrote {len(trades)} round trips and reports to {REPORT_DIR}."
    )
    print(
        json.dumps(
            {
                "metrics": asdict(metrics),
                "cycles": cycles,
                "reports": {name: str(path) for name, path in report_paths.items()},
            },
            indent=2,
        )
    )


def sweep_saved_config(args: argparse.Namespace) -> None:
    status(f"Loading saved configuration from {args.config} for a leverage/profit-lock sweep.")
    payload = json.loads(Path(args.config).read_text(encoding="utf-8"))
    data_start = (utc_timestamp(payload["start"]) - pd.DateOffset(days=args.warmup_days)).date().isoformat()
    one_hour = fetch_binance_klines(payload["symbol"], data_start, payload["end"], CACHE_DIR)
    status(f"Resampling {len(one_hour):,} 1h candles to {payload['timeframe']} candles.")
    df = resample_ohlcv(one_hour, payload["timeframe"])
    locks = [float(item) for item in args.profit_locks.split(",") if item.strip()]
    leverages = [round(x, 2) for x in np.arange(args.min_leverage, args.max_leverage + 0.001, args.leverage_step)]
    fee_rate = float(payload["fee_bps"]) / 10000.0
    slippage_rate = float(payload["slippage_bps"]) / 10000.0
    total_runs = len(locks) * len(leverages)
    status(
        f"Starting {total_runs} sweep backtests: {len(locks)} profit-lock settings x "
        f"{len(leverages)} leverage levels."
    )

    results: list[dict[str, Any]] = []
    completed_runs = 0
    progress_every = max(1, math.ceil(total_runs / 20))
    for lock in locks:
        cfg = dict(payload["config"])
        cfg["cycle_profit_lock_pct"] = lock
        cfg["cycle_loss_stop_pct"] = 0.0
        status(f"Building signal with a {lock:g}% two-month profit lock.")
        signal = build_signal(df, cfg)
        for leverage in leverages:
            completed_runs += 1
            metrics, equity, returns, cycles = backtest(
                df=df,
                signal=signal,
                leverage=leverage,
                fee_rate=fee_rate,
                slippage_rate=slippage_rate,
                start=payload["start"],
                end=payload["end"],
                timeframe=payload["timeframe"],
                cycle_profit_lock_pct=lock,
                cycle_loss_stop_pct=0.0,
            )
            results.append(
                {
                    "score": score_metrics(metrics, args.target_profit_pct),
                    "config": cfg,
                    "leverage": leverage,
                    "metrics": metrics,
                    "cycles": cycles,
                    "equity": equity,
                    "returns": returns,
                }
            )
            if completed_runs % progress_every == 0 or completed_runs == total_runs:
                status(
                    f"Sweep progress {completed_runs}/{total_runs}: last run used "
                    f"{leverage:g}x leverage and a {lock:g}% profit lock "
                    f"(return={metrics.total_return_pct:.1f}%)."
                )

    successes = [
        item
        for item in results
        if item["metrics"].total_return_pct >= args.target_profit_pct
        and item["metrics"].positive_cycles == item["metrics"].cycle_count
        and not item["metrics"].blown_up
    ]
    if successes:
        chosen = sorted(
            successes,
            key=lambda item: (
                item["leverage"],
                abs(item["metrics"].max_drawdown_pct),
                item["metrics"].total_return_pct - args.target_profit_pct,
            ),
        )[0]
        success = True
    else:
        chosen = sorted(results, key=lambda item: item["score"], reverse=True)[0]
        success = False

    leaderboard = sorted(
        results,
        key=lambda item: (
            item["metrics"].positive_cycles == item["metrics"].cycle_count,
            item["metrics"].total_return_pct >= args.target_profit_pct,
            -item["leverage"],
            item["score"],
        ),
        reverse=True,
    )[: args.keep_top]
    chosen_metrics: Metrics = chosen["metrics"]
    status(
        f"Sweep finished. Selected {chosen['leverage']:g}x leverage with a "
        f"{float(chosen['config'].get('cycle_profit_lock_pct', 0.0)):g}% profit lock: "
        f"return={chosen_metrics.total_return_pct:.1f}%, "
        f"positive cycles={chosen_metrics.positive_cycles}/{chosen_metrics.cycle_count}."
    )
    report_args = argparse.Namespace(
        symbol=payload["symbol"],
        start=payload["start"],
        end=payload["end"],
        fee_bps=payload["fee_bps"],
        slippage_bps=payload["slippage_bps"],
        target_profit_pct=args.target_profit_pct,
        max_candidates=len(results),
        min_leverage=args.min_leverage,
        max_leverage=args.max_leverage,
        leverage_step=args.leverage_step,
        keep_top=args.keep_top,
        warmup_days=args.warmup_days,
    )
    status("Writing reports for the selected sweep result.")
    write_report(chosen=chosen, leaderboard=leaderboard, args=report_args, success=success)
    status(f"Sweep complete. Reports are available in {REPORT_DIR}.")
    print(json.dumps(serializable_result(chosen), indent=2))


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="BTCUSDT Binance strategy optimizer and backtester.")
    sub = parser.add_subparsers(dest="command", required=True)

    opt = sub.add_parser("optimize", help="Fetch Binance data, search strategy candidates, and write reports.")
    opt.add_argument("--symbol", default=DEFAULT_SYMBOL)
    opt.add_argument("--start", default=DEFAULT_START)
    opt.add_argument("--end", default=DEFAULT_END)
    opt.add_argument("--max-candidates", type=int, default=3000)
    opt.add_argument("--seed", type=int, default=7)
    opt.add_argument("--min-leverage", type=float, default=1.0)
    opt.add_argument("--max-leverage", type=float, default=12.0)
    opt.add_argument("--leverage-step", type=float, default=0.5)
    opt.add_argument("--fee-bps", type=float, default=4.0)
    opt.add_argument("--slippage-bps", type=float, default=1.0)
    opt.add_argument("--target-profit-pct", type=float, default=1000.0)
    opt.add_argument("--warmup-days", type=int, default=365)
    opt.add_argument("--refine-top", type=int, default=5)
    opt.add_argument("--refine-profit-locks", default="0,5,8,10,12,15,20,30")
    opt.add_argument("--keep-top", type=int, default=25)
    opt.add_argument("--progress-every", type=int, default=100)
    opt.add_argument("--verbose", action="store_true")

    saved = sub.add_parser("backtest", help="Re-run a saved reports/best_config.json.")
    saved.add_argument("--config", default=str(REPORT_DIR / "best_config.json"))

    sweep = sub.add_parser("sweep-saved", help="Sweep leverage/profit locks around a saved signal config.")
    sweep.add_argument("--config", default=str(REPORT_DIR / "best_config.json"))
    sweep.add_argument("--min-leverage", type=float, default=1.0)
    sweep.add_argument("--max-leverage", type=float, default=12.0)
    sweep.add_argument("--leverage-step", type=float, default=0.5)
    sweep.add_argument("--profit-locks", default="0,5,8,10,12,15,20,30")
    sweep.add_argument("--target-profit-pct", type=float, default=1000.0)
    sweep.add_argument("--warmup-days", type=int, default=365)
    sweep.add_argument("--keep-top", type=int, default=25)

    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.command == "optimize":
        chosen = optimize(args)
        metrics: Metrics = chosen["metrics"]
        print(
            json.dumps(
                {
                    "strategy": chosen["config"]["strategy"],
                    "timeframe": chosen["config"]["timeframe"],
                    "leverage": chosen["leverage"],
                    "metrics": asdict(metrics),
                    "report": str(REPORT_DIR / "backtest_report.md"),
                },
                indent=2,
            )
        )
    elif args.command == "backtest":
        run_saved_config(args)
    elif args.command == "sweep-saved":
        sweep_saved_config(args)


if __name__ == "__main__":
    main()
