"""Closed-candle Binance USDⓈ-M Futures executor for ``btc_backtester.py``.

The signal feed intentionally uses Binance *spot* 1h candles resampled to the
saved timeframe, because that is exactly the data path used by the backtester.
Orders use Binance USDⓈ-M Futures because leverage is a futures feature.

Run dry first (the default):

    conda run --no-capture-output -n crypto3 python btc_live_bot.py --once

Live trading requires both --live and LIVE_TRADING_CONFIRM=I_UNDERSTAND_RISK.
Read LIVE_BOT.md before using either form with credentials.
"""

from __future__ import annotations

import argparse
import csv
import html
import json
import logging
import math
import os
import signal
import sys
import threading
import time
import traceback
import urllib.parse
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from decimal import Decimal, ROUND_DOWN
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from binance.client import Client

import btc_backtester as bt


UTC = timezone.utc
IST = timezone(timedelta(hours=5, minutes=30), name="IST")
ROOT = Path(__file__).resolve().parent
DEFAULT_CONFIG = ROOT / "reports" / "best_config.json"
DEFAULT_LIVE_STATE = ROOT / "live_state.json"
DEFAULT_TESTNET_STATE = ROOT / "testnet_state.json"
DEFAULT_PAPER_STATE = ROOT / "paper_state.json"
DEFAULT_LIVE_TRADES = ROOT / "reports" / "main_trades.csv"
DEFAULT_TESTNET_TRADES = ROOT / "reports" / "test_trades.csv"
DEFAULT_PAPER_TRADES = ROOT / "paper_trades.csv"
DEFAULT_LOG = ROOT / "log.txt"
LIVE_CONFIRMATION = "I_UNDERSTAND_RISK"


class BotError(RuntimeError):
    """A problem that should leave the bot safe and flat rather than guessing."""


@dataclass(frozen=True)
class SymbolRules:
    step_size: Decimal
    min_qty: Decimal
    min_notional: Decimal


@dataclass(frozen=True)
class OrderFill:
    order_id: str
    client_order_id: str
    quantity: float
    average_price: float
    commission_usdt: float
    realized_pnl: float
    commission_is_estimate: bool


def utc_now() -> pd.Timestamp:
    return pd.Timestamp.now(tz="UTC")


def iso_time(value: pd.Timestamp | datetime) -> str:
    timestamp = pd.Timestamp(value)
    if timestamp.tzinfo is None:
        timestamp = timestamp.tz_localize("UTC")
    return timestamp.tz_convert(IST).isoformat()


def same_instant(left: Any, right: pd.Timestamp | datetime) -> bool:
    if left is None or (isinstance(left, str) and not left.strip()):
        return False
    try:
        return pd.Timestamp(iso_time(left)) == pd.Timestamp(iso_time(right))
    except (TypeError, ValueError):
        return False


def configure_logging(log_path: Path, verbose: bool) -> logging.Logger:
    logger = logging.getLogger("btc_live_bot")
    logger.setLevel(logging.DEBUG)
    logger.handlers.clear()
    logger.propagate = False

    formatter = logging.Formatter(
        fmt="%(asctime)s IST | %(levelname)-8s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    formatter.converter = lambda timestamp: datetime.fromtimestamp(timestamp, tz=IST).timetuple()

    console = logging.StreamHandler(sys.stdout)
    console.setLevel(logging.DEBUG if verbose else logging.INFO)
    console.setFormatter(formatter)
    logger.addHandler(console)

    file_handler = RotatingFileHandler(
        log_path,
        maxBytes=5_000_000,
        backupCount=5,
        encoding="utf-8",
    )
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    return logger


def load_env_file(path: Path, logger: logging.Logger) -> None:
    """Load simple KEY=value lines without overriding environment variables."""
    if not path.exists():
        return
    for number, raw_line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            logger.warning("Ignoring malformed %s line %d.", path, number)
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key and key not in os.environ:
            os.environ[key] = value


def atomic_json_write(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")
    os.replace(temporary, path)


def load_state(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise BotError(f"State file {path} is not valid JSON: {exc}") from exc
    if not isinstance(data, dict):
        raise BotError(f"State file {path} must contain a JSON object.")
    return data


def append_trade(path: Path, row: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    write_header = not path.exists() or path.stat().st_size == 0
    with path.open("a", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=bt.TRADE_COLUMNS)
        if write_header:
            writer.writeheader()
        writer.writerow({column: row.get(column, "") for column in bt.TRADE_COLUMNS})


def decimal_floor(value: float, step: Decimal) -> Decimal:
    if step <= 0:
        raise BotError("Exchange returned a non-positive lot step.")
    raw = Decimal(str(max(0.0, value)))
    return (raw / step).to_integral_value(rounding=ROUND_DOWN) * step


def size_target_quantity(
    desired_unit: float,
    equity: float,
    mark_price: float,
    leverage: float,
    margin_utilization: float,
    step_size: float | Decimal,
    min_qty: float | Decimal,
    min_notional: float | Decimal,
) -> tuple[float, float]:
    """Return the unrounded and exchange-rounded target BTC quantity."""
    if desired_unit == 0.0:
        return 0.0, 0.0
    if equity <= 0.0 or mark_price <= 0.0:
        raise BotError("Equity and mark price must be positive for position sizing.")
    margin_budget = equity * margin_utilization
    raw_quantity = abs(desired_unit) * leverage * margin_budget / mark_price
    rounded = decimal_floor(raw_quantity, Decimal(str(step_size)))
    notional = rounded * Decimal(str(mark_price))
    if rounded < Decimal(str(min_qty)) or notional < Decimal(str(min_notional)):
        return raw_quantity, 0.0
    return raw_quantity, math.copysign(float(rounded), desired_unit)


def decimal_text(value: Decimal) -> str:
    return format(value.normalize(), "f") if value != 0 else "0"


def signed_side(delta_qty: float) -> str:
    return "BUY" if delta_qty > 0.0 else "SELL"


class TelegramNotifier:
    def __init__(self, token: str | None, chat_id: str | None, logger: logging.Logger) -> None:
        self.token = token
        self.chat_id = chat_id
        self.logger = logger
        self.enabled = bool(token and chat_id)
        if not self.enabled:
            self.logger.info("Telegram notifications disabled: TELEGRAM_BOT_TOKEN and/or TELEGRAM_CHAT_ID absent.")

    def send(self, text: str) -> None:
        if not self.enabled:
            return
        message = self._format_message(text[:3500])
        payload = urllib.parse.urlencode(
            {
                "chat_id": self.chat_id,
                "text": message,
                "parse_mode": "HTML",
                "disable_web_page_preview": "true",
            }
        ).encode("utf-8")
        url = f"https://api.telegram.org/bot{self.token}/sendMessage"
        request = urllib.request.Request(url, data=payload, method="POST")
        try:
            with urllib.request.urlopen(request, timeout=15) as response:
                response_body = json.loads(response.read().decode("utf-8"))
            if not response_body.get("ok"):
                raise BotError(str(response_body.get("description", "unknown Telegram error")))
        except Exception as exc:  # Notifications must never interrupt trading logic.
            self.logger.warning("Telegram notification failed: %s", exc)

    @staticmethod
    def _format_message(text: str) -> str:
        """Present plain notification text as a compact, escaped Telegram card."""
        lines = text.strip().splitlines()
        if not lines:
            return "<b>📡 BTC bot update</b>"

        title = lines[0].strip()
        title_lower = title.lower()
        if "error" in title_lower or "failed" in title_lower:
            icon = "🚨"
        elif "started" in title_lower:
            icon = "🚀"
        elif "stopped" in title_lower:
            icon = "🛑"
        elif "trade closed" in title_lower:
            icon = "💰"
        elif "opened" in title_lower:
            icon = "📈" if "long" in title_lower else "📉"
        elif "no order" in title_lower:
            icon = "⏸️"
        else:
            icon = "✅"

        body_lines: list[str] = []
        for line in lines[1:]:
            if not line.strip():
                body_lines.append("")
                continue

            escaped_line = html.escape(line.strip(), quote=False)
            if ":" in line:
                label, value = line.split(":", 1)
                if label and len(label) <= 40 and "\n" not in label:
                    body_lines.append(
                        f"<b>{html.escape(label.strip(), quote=False)}:</b>"
                        f"{html.escape(value, quote=False)}"
                    )
                    continue

            separator = " | " if " | " in line else "; " if "; " in line else None
            if separator and "=" in line:
                fields = []
                for field in line.strip().split(separator):
                    label, equals, value = field.partition("=")
                    if equals and label.strip() and len(label.strip()) <= 24:
                        fields.append(
                            f"<b>{html.escape(label.strip().replace('_', ' '), quote=False)}:</b> "
                            f"<code>{html.escape(value.strip(), quote=False)}</code>"
                        )
                    else:
                        fields.append(html.escape(field.strip(), quote=False))
                body_lines.append("   ·   ".join(fields))
                continue

            body_lines.append(escaped_line)

        header = f"<b>{icon} {html.escape(title, quote=False)}</b>"
        if not body_lines:
            return header
        return header + "\n<code>━━━━━━━━━━━━━━━━</code>\n" + "\n".join(body_lines)


class BinanceLiveBot:
    def __init__(self, args: argparse.Namespace, payload: dict[str, Any], logger: logging.Logger) -> None:
        self.args = args
        self.payload = payload
        self.logger = logger
        self.symbol = str(payload["symbol"]).upper()
        self.config = dict(payload["config"])
        self.timeframe = str(payload["timeframe"])
        self.hours = int(self.timeframe.removesuffix("h"))
        if self.hours <= 0:
            raise BotError(f"Only hour-based timeframes are supported, got {self.timeframe!r}.")
        self.bar_delta = pd.Timedelta(hours=self.hours)
        self.leverage = float(payload["leverage"])
        if not self.leverage.is_integer():
            raise BotError(
                f"Saved leverage {self.leverage:g}x is not executable by this bot. "
                "Binance Futures leverage settings are whole numbers."
            )
        self.cost_rate = (float(payload["fee_bps"]) + float(payload["slippage_bps"])) / 10_000.0
        self.fee_rate = float(payload["fee_bps"]) / 10_000.0
        self.is_live = bool(args.live)
        self.backtest_parity = bool(getattr(args, "backtest_parity", False))
        requested_margin_utilization = getattr(args, "margin_utilization", None)
        if self.backtest_parity and requested_margin_utilization is not None and not math.isclose(
            float(requested_margin_utilization), 1.0, rel_tol=0.0, abs_tol=1e-12
        ):
            raise BotError("--backtest-parity requires --margin-utilization 1.0 (or omit that option).")
        if self.backtest_parity:
            self.margin_utilization = 1.0
        elif requested_margin_utilization is not None:
            self.margin_utilization = float(requested_margin_utilization)
        else:
            self.margin_utilization = 0.90 if self.is_live else 1.0
        if not 0.0 < self.margin_utilization <= 1.0:
            raise BotError("--margin-utilization must be greater than 0 and at most 1.")
        default_state = (
            DEFAULT_TESTNET_STATE if args.testnet else DEFAULT_LIVE_STATE
        ) if self.is_live else DEFAULT_PAPER_STATE
        default_trades = (
            DEFAULT_TESTNET_TRADES if args.testnet else DEFAULT_LIVE_TRADES
        ) if self.is_live else DEFAULT_PAPER_TRADES
        self.state_path = Path(args.state) if args.state else default_state
        self.trades_path = Path(args.trades) if args.trades else default_trades
        self.state = load_state(self.state_path)
        expected_mode = "testnet" if self.is_live and args.testnet else "live" if self.is_live else "paper"
        stored_mode = self.state.get("mode")
        if stored_mode and stored_mode != expected_mode:
            raise BotError(
                f"State file {self.state_path} belongs to {stored_mode!r} mode, not {expected_mode!r}. "
                "Use the default per-mode state file or provide a different --state path."
            )
        self.notifier = TelegramNotifier(
            os.getenv("TELEGRAM_BOT_TOKEN"), os.getenv("TELEGRAM_CHAT_ID"), logger
        )
        self.pending_decision_context: str | None = None
        self.shutdown_event = threading.Event()
        self.symbol_rules: SymbolRules | None = None

        api_key = os.getenv("BINANCE_API_KEY")
        api_secret = os.getenv("BINANCE_API_SECRET")
        if self.is_live:
            if os.getenv("LIVE_TRADING_CONFIRM") != LIVE_CONFIRMATION:
                raise BotError(
                    "Live mode requires LIVE_TRADING_CONFIRM=I_UNDERSTAND_RISK in the environment file."
                )
            if not api_key or not api_secret:
                raise BotError("Live mode requires BINANCE_API_KEY and BINANCE_API_SECRET.")
        self.client = Client(api_key=api_key, api_secret=api_secret, testnet=bool(args.testnet))
        # Binance Spot Testnet has only a short candle history. Keep the
        # strategy feed on public Spot mainnet data even when Futures execution
        # is pointed at testnet; that also matches the backtest's data source.
        self.market_data_client = Client() if args.testnet else self.client

        self._validate_payload()

    def _validate_payload(self) -> None:
        required = {"symbol", "start", "config", "timeframe", "leverage", "fee_bps", "slippage_bps"}
        missing = required - set(self.payload)
        if missing:
            raise BotError(f"Saved config is missing required fields: {sorted(missing)}")
        if self.config.get("timeframe") != self.timeframe:
            raise BotError("The top-level and nested saved timeframes do not match.")

    def notify(self, text: str) -> None:
        self.notifier.send(text)

    def request_shutdown(self, signum: int, frame: Any) -> None:
        """Defer Ctrl+C until the current decision/order operation reaches a safe point."""
        self.shutdown_event.set()

    def save_shutdown_state(self) -> None:
        """Persist the last reconciled state without changing or closing exposure."""
        tracked_key = "live_position_qty" if self.is_live else "paper_position_qty"
        tracked_qty = float(self.state.get(tracked_key, 0.0))
        if self.is_live:
            try:
                actual_qty = self.current_position_qty()
            except Exception as exc:
                self.logger.warning(
                    "Could not confirm Binance position during shutdown; saving last tracked quantity %+.6f BTC: %s",
                    tracked_qty, exc,
                )
            else:
                if abs(actual_qty - tracked_qty) > 1e-8:
                    self.logger.error(
                        "Shutdown position mismatch: Binance=%+.6f BTC, saved bot state=%+.6f BTC. "
                        "Saving tracked state; startup will require reconciliation.",
                        actual_qty, tracked_qty,
                    )
        self.save_state()
        self.logger.info(
            "State safely saved to %s. Existing %s position remains open at %+.6f BTC; no shutdown order was sent.",
            self.state_path, self.symbol, tracked_qty,
        )
        self.notify(
            f"{self.symbol} bot stopped safely. State saved to {self.state_path.name}.\n"
            f"Saved position={tracked_qty:+.6f} BTC; no shutdown order was sent. "
            "Restart with the same mode to resume checking completed candles."
        )

    def save_state(self) -> None:
        self.state["schema_version"] = 1
        self.state["mode"] = "testnet" if self.is_live and self.args.testnet else "live" if self.is_live else "paper"
        self.state["symbol"] = self.symbol
        self.state["timeframe"] = self.timeframe
        self.state["updated_at"] = iso_time(utc_now())
        last_processed = self.state.get("last_processed_candle")
        if last_processed:
            self.state["last_processed_candle"] = iso_time(last_processed)
        cycle = self.state.get("cycle")
        if isinstance(cycle, dict):
            for key in ("start", "end"):
                if cycle.get(key):
                    cycle[key] = iso_time(cycle[key])
        active_trade = self.state.get("active_trade")
        if isinstance(active_trade, dict) and active_trade.get("entry_time"):
            active_trade["entry_time"] = iso_time(active_trade["entry_time"])
        atomic_json_write(self.state_path, self.state)

    def startup_message(self) -> str:
        mode = "LIVE" if self.is_live else "DRY RUN"
        return (
            f"BTC live bot started ({mode})\n"
            f"Symbol: {self.symbol} | signal feed: spot 1h → {self.timeframe}\n"
            f"Execution venue: USDⓈ-M Futures | leverage: {self.leverage:g}x\n"
            f"Margin sizing cap: {self.margin_utilization:.0%} of account equity\n"
            f"Sizing model: {'backtest parity target' if self.backtest_parity else 'configured target'}\n"
            f"Strategy: {self.config['strategy']} | config: {Path(self.args.config).name}\n"
            f"Poll: {self.args.poll_seconds}s"
        )

    def fetch_symbol_rules(self) -> SymbolRules:
        information = self.client.futures_exchange_info()
        details = next((item for item in information["symbols"] if item["symbol"] == self.symbol), None)
        if details is None:
            raise BotError(f"{self.symbol} is not available on Binance USDⓈ-M Futures.")
        if details.get("status") != "TRADING":
            raise BotError(f"{self.symbol} Futures status is {details.get('status')!r}, not TRADING.")
        filters = {item["filterType"]: item for item in details["filters"]}
        lot_filter = filters.get("MARKET_LOT_SIZE") or filters.get("LOT_SIZE")
        if not lot_filter:
            raise BotError(f"No market lot-size filter found for {self.symbol}.")
        notional_filter = filters.get("MIN_NOTIONAL") or filters.get("NOTIONAL") or {}
        rules = SymbolRules(
            step_size=Decimal(str(lot_filter["stepSize"])),
            min_qty=Decimal(str(lot_filter["minQty"])),
            min_notional=Decimal(str(notional_filter.get("notional", notional_filter.get("minNotional", 0)))),
        )
        self.logger.info(
            "Exchange rules: market step=%s, min_qty=%s, min_notional=%s USDT.",
            decimal_text(rules.step_size),
            decimal_text(rules.min_qty),
            decimal_text(rules.min_notional),
        )
        return rules

    def current_position_qty(self) -> float:
        if not self.is_live:
            return float(self.state.get("paper_position_qty", 0.0))
        # Position-risk may omit symbols with zero position (as happened on
        # Futures testnet). Account information includes the symbol rows even
        # when flat, which lets startup distinguish flat from unknown state.
        positions = self.client.futures_account().get("positions", [])
        matching = [item for item in positions if item.get("symbol") == self.symbol]
        if not matching:
            raise BotError(f"No position information returned for {self.symbol}.")
        return float(matching[0]["positionAmt"])

    def current_equity(self) -> float:
        if not self.is_live:
            return float(self.state.setdefault("paper_equity", float(self.args.paper_equity)))
        account = self.client.futures_account()
        equity = float(account["totalMarginBalance"])
        if equity <= 0.0:
            raise BotError(f"Account totalMarginBalance is non-positive ({equity}).")
        return equity

    def current_mark_price(self) -> float:
        price = float(self.client.futures_mark_price(symbol=self.symbol)["markPrice"])
        if price <= 0.0:
            raise BotError(f"Invalid Binance Futures mark price: {price}")
        return price

    def live_preflight(self) -> None:
        if not self.is_live:
            self.logger.warning(
                "DRY RUN only: orders are simulated; no Binance Futures order can be submitted. "
                "Use --live only after paper validation."
            )
            return
        if self.backtest_parity:
            self.logger.warning(
                "BACKTEST-PARITY SIZING IS ACTIVE: targets may use 100%% of account equity as initial margin, "
                "leaving no reserve and materially increasing rejection/liquidation risk."
            )
        mode = self.client.futures_get_position_mode()
        if str(mode.get("dualSidePosition", "false")).lower() == "true":
            raise BotError("Hedge Mode is enabled. This bot requires Binance One-way Mode (positionSide=BOTH).")
        account = self.client.futures_account()
        all_positions = account.get("positions", [])
        if not isinstance(all_positions, list):
            raise BotError("Binance Futures account response did not contain a positions list.")
        other_positions = [
            item for item in all_positions
            if item.get("symbol") != self.symbol and abs(float(item.get("positionAmt", 0.0))) > 1e-12
        ]
        if other_positions:
            symbols = ", ".join(item["symbol"] for item in other_positions)
            raise BotError(f"Refusing to size from an account with other open Futures positions: {symbols}.")
        open_orders = self.client.futures_get_open_orders(symbol=self.symbol)
        if open_orders:
            raise BotError(
                f"Refusing to start with {len(open_orders)} existing open order(s) on {self.symbol}; cancel or reconcile them first."
            )
        position_details = next((item for item in all_positions if item.get("symbol") == self.symbol), None)
        if position_details is None:
            raise BotError(f"No USDⓈ-M Futures position metadata returned for {self.symbol}.")
        isolated_value = position_details.get("isolated")
        if isolated_value is None:
            margin_type = str(position_details.get("marginType", "")).lower()
            if margin_type not in {"cross", "crossed", "isolated"}:
                raise BotError(f"Could not determine {self.symbol} margin type from Binance Futures account data.")
            is_isolated = margin_type == "isolated"
        elif isinstance(isolated_value, bool):
            is_isolated = isolated_value
        else:
            is_isolated = str(isolated_value).lower() in {"true", "1"}
        if is_isolated:
            raise BotError(
                f"{self.symbol} is configured for Isolated margin. "
                "This account-level sizing bot requires Cross margin."
            )
        actual_qty = self.current_position_qty()
        tracked_qty = float(self.state.get("live_position_qty", 0.0))
        if abs(actual_qty - tracked_qty) > 1e-8:
            raise BotError(
                f"Actual {self.symbol} position ({actual_qty}) does not match persistent bot state ({tracked_qty}). "
                "Do not let the bot adopt an unmanaged position; reconcile it first."
            )
        self.client.futures_change_leverage(symbol=self.symbol, leverage=int(self.leverage))
        self.logger.info("Live preflight passed: One-way Mode, no unmanaged orders/positions, leverage set to %gx.", self.leverage)

    def fetch_closed_signal_data(self) -> pd.DataFrame:
        warmup = int(self.config.get("warmup", 0))
        # The backtester fetches ``warmup_days`` of candle history before its
        # evaluation window. Preserve at least that much history here so EMA,
        # ATR, and volatility values are initialized the same way rather than
        # from merely the strategy's explicit signal-suppression warmup.
        backtest_warmup_bars = math.ceil(int(self.payload.get("warmup_days", 365)) * 24 / self.hours)
        required_bars = max(
            backtest_warmup_bars,
            warmup + 3,
            int(self.config.get("anchor", 0)) + 3,
            int(self.config.get("atr_len", 14)) + 3,
            int(self.config.get("vol_lookback", 48)) + 3,
            100,
        )
        history_start = utc_now() - pd.Timedelta(hours=(required_bars + 6) * self.hours)
        rows = self.market_data_client.get_historical_klines(
            symbol=self.symbol,
            interval=Client.KLINE_INTERVAL_1HOUR,
            start_str=history_start.isoformat(),
            end_str=utc_now().isoformat(),
        )
        if not rows:
            raise BotError("Binance returned no spot 1h candle data.")
        raw = pd.DataFrame(rows, columns=bt.KLINE_COLUMNS)
        numeric_columns = [
            "open", "high", "low", "close", "volume", "quote_volume", "trade_count",
            "taker_buy_base_volume", "taker_buy_quote_volume",
        ]
        for column in numeric_columns:
            raw[column] = pd.to_numeric(raw[column], errors="coerce")
        raw["open_time"] = pd.to_datetime(raw["open_time"], unit="ms", utc=True)
        raw["close_time"] = pd.to_datetime(raw["close_time"], unit="ms", utc=True)
        source = raw.set_index("open_time").sort_index()
        source = source[
            [
                "open", "high", "low", "close", "volume", "quote_volume", "trade_count",
                "taker_buy_base_volume", "taker_buy_quote_volume", "close_time",
            ]
        ]
        cutoff = utc_now() - pd.Timedelta(seconds=self.args.candle_settle_seconds)
        source = source[source["close_time"] <= cutoff]
        resampled = bt.resample_ohlcv(source, self.timeframe)
        closed = resampled[(resampled.index + self.bar_delta) <= cutoff]
        if len(closed) < required_bars:
            raise BotError(
                f"Only {len(closed)} completed {self.timeframe} candles are available; need {required_bars}."
            )
        return closed

    def cycle_window(self, bar_open: pd.Timestamp) -> tuple[pd.Timestamp, pd.Timestamp]:
        anchor = bt.utc_timestamp(str(self.payload["start"]))
        timestamp = pd.Timestamp(bar_open).tz_convert("UTC")
        left = anchor
        right = left + pd.DateOffset(months=2)
        while timestamp >= right:
            left = right
            right = left + pd.DateOffset(months=2)
        return left, right

    def ensure_cycle_state(self, bar_open: pd.Timestamp, equity: float) -> dict[str, Any]:
        left, right = self.cycle_window(bar_open)
        cycle = self.state.get("cycle")
        if not isinstance(cycle, dict) or not same_instant(cycle.get("start"), left):
            cycle = {
                "start": iso_time(left),
                "end": iso_time(right),
                "start_equity": float(equity),
                "locked": False,
                "lock_reason": "",
                "baseline_note": "initialized_or_new_cycle",
            }
            self.state["cycle"] = cycle
            self.logger.warning(
                "Cycle baseline set to %.4f USDT for %s to %s. If this is a mid-cycle first launch, "
                "the current cycle's lock cannot reproduce historical backtest equity.",
                equity,
                iso_time(left),
                iso_time(right),
            )
        return cycle

    def advance_cycle_after_boundary(self, next_bar_open: pd.Timestamp, equity: float) -> None:
        left, right = self.cycle_window(next_bar_open)
        old_cycle = self.state.get("cycle", {})
        if same_instant(old_cycle.get("start"), left):
            return
        self.state["cycle"] = {
            "start": iso_time(left),
            "end": iso_time(right),
            "start_equity": float(equity),
            "locked": False,
            "lock_reason": "",
            "baseline_note": "new_cycle_boundary",
        }
        self.logger.info(
            "New two-month cycle: %s to %s; baseline equity %.4f USDT.",
            iso_time(left), iso_time(right), equity,
        )

    def signal_details(self, candles: pd.DataFrame, desired_unit: float) -> tuple[str, dict[str, float]]:
        latest = candles.iloc[-1]
        close = float(latest["close"])
        values: dict[str, float] = {"close": close, "desired_unit": desired_unit}
        if self.config["strategy"] != "supertrend":
            return (
                f"strategy={self.config['strategy']}; close={close:.2f}; "
                f"final signal unit={desired_unit:+.4f}",
                values,
            )
        atr_len = int(self.config["atr_len"])
        raw_direction = bt.supertrend_direction(candles, atr_len, float(self.config["multiplier"])).iloc[-1]
        raw_direction = float(raw_direction)
        anchor_len = int(self.config.get("anchor", 0))
        anchor = float(bt.ema(candles["close"], anchor_len).iloc[-1]) if anchor_len else close
        atr_value = float(bt.atr(candles, atr_len).iloc[-1])
        atr_pct = atr_value / close if close else math.inf

        ema_pass = True
        if raw_direction > 0 and anchor_len:
            ema_pass = close > anchor
            ema_gate = f"long {'pass' if ema_pass else 'BLOCK'}: close {'>' if ema_pass else '<='} EMA"
        elif raw_direction < 0 and anchor_len:
            ema_pass = close < anchor
            ema_gate = f"short {'pass' if ema_pass else 'BLOCK'}: close {'<' if ema_pass else '>='} EMA"
        elif anchor_len:
            ema_gate = "no directional Supertrend signal"
        else:
            ema_gate = "disabled"
        ema_direction = raw_direction if ema_pass else 0.0

        vol_scale = 1.0
        vol_target = float(self.config.get("vol_target", 0.0))
        vol_desc = "off; scale=1.0000"
        if vol_target > 0:
            vol_lookback = int(self.config.get("vol_lookback", 48))
            realized = candles["close"].pct_change().rolling(
                vol_lookback,
                min_periods=vol_lookback,
            ).std().iloc[-1]
            annualized = float(realized) * math.sqrt(bt.bars_per_year_for_timeframe(self.timeframe))
            max_unit = float(self.config.get("max_unit", 1.0))
            vol_scale = min(max_unit, vol_target / annualized) if math.isfinite(annualized) and annualized > 0 else 0.0
            annualized_text = f"{annualized:.1%}" if math.isfinite(annualized) else "unavailable"
            vol_desc = (
                f"annualized={annualized_text}, target={vol_target:.1%}, "
                f"scale={vol_scale:.4f} (cap={max_unit:.4f}, lookback={vol_lookback})"
            )
            values["annualized_vol"] = annualized

        vol_adjusted_unit = ema_direction * vol_scale
        max_atr_pct = float(self.config.get("max_atr_pct", 0.0))
        atr_pass = max_atr_pct <= 0.0 or (math.isfinite(atr_pct) and atr_pct <= max_atr_pct)
        after_atr = vol_adjusted_unit if atr_pass else 0.0
        atr_gate = (
            f"ATR({atr_len})={atr_value:.2f} ({atr_pct:.2%}); limit=off"
            if max_atr_pct <= 0.0
            else f"ATR({atr_len})={atr_value:.2f} ({atr_pct:.2%}); limit={max_atr_pct:.2%} {'pass' if atr_pass else 'BLOCK'}"
        )
        warmup = int(self.config.get("warmup", 0))
        warmup_blocked = len(candles) - 1 < warmup
        warmup_text = f"BLOCK ({len(candles)-1}/{warmup} bars)" if warmup_blocked else "passed"

        values.update({
            "raw_supertrend": raw_direction, "anchor": anchor, "atr": atr_value,
            "atr_pct": float(atr_pct), "vol_scale": float(vol_scale),
            "ema_gate_pass": float(ema_pass), "atr_gate_pass": float(atr_pass),
            "warmup_blocked": float(warmup_blocked), "vol_adjusted_unit": float(vol_adjusted_unit),
            "after_atr_unit": float(after_atr),
        })
        raw_label = "bullish" if raw_direction > 0 else "bearish" if raw_direction < 0 else "neutral"
        detail = (
            f"close={close:.2f}; Supertrend({atr_len}, mult={self.config['multiplier']})={raw_label} ({raw_direction:+.0f}); "
            f"EMA({anchor_len})={anchor:.2f} [{ema_gate}]; {vol_desc}; {atr_gate}; "
            f"unit after EMA={ema_direction:+.0f}, after volatility={vol_adjusted_unit:+.4f}, "
            f"after ATR={after_atr:+.4f}; warmup={warmup_text}; final unit={desired_unit:+.4f}"
        )
        return detail, values

    def paper_mark_to_close(self, close_price: float) -> None:
        if self.is_live:
            return
        previous_mark = self.state.get("paper_last_mark_price")
        qty = float(self.state.get("paper_position_qty", 0.0))
        if previous_mark is not None:
            pnl = qty * (close_price - float(previous_mark))
            self.state["paper_equity"] = float(self.state.get("paper_equity", self.args.paper_equity)) + pnl
            self.logger.info(
                "Dry-run mark-to-market: qty=%+.6f, %.2f → %.2f, P&L=%+.4f USDT, equity=%.4f USDT.",
                qty, float(previous_mark), close_price, pnl, float(self.state["paper_equity"]),
            )
        self.state["paper_last_mark_price"] = close_price

    def target_quantity(self, desired_unit: float, equity: float, mark_price: float) -> float:
        if desired_unit == 0.0:
            return 0.0
        if self.symbol_rules is None:
            raise BotError("Symbol rules are unavailable.")
        raw_quantity, rounded_target = size_target_quantity(
            desired_unit=desired_unit,
            equity=equity,
            mark_price=mark_price,
            leverage=self.leverage,
            margin_utilization=self.margin_utilization,
            step_size=self.symbol_rules.step_size,
            min_qty=self.symbol_rules.min_qty,
            min_notional=self.symbol_rules.min_notional,
        )
        if rounded_target == 0.0:
            rounded = decimal_floor(raw_quantity, self.symbol_rules.step_size)
            notional = rounded * Decimal(str(mark_price))
            self.logger.warning(
                "Desired %.8f BTC (%.2f USDT) falls below Futures minimum; target forced flat.",
                raw_quantity, float(notional),
            )
            return 0.0
        return rounded_target

    def current_live_order_fills(
        self,
        order_id: str,
        client_order_id: str,
        fallback_qty: float,
        fallback_price: float,
    ) -> OrderFill:
        """Fetch fills for actual fees/P&L; use a conservative estimate only if unavailable."""
        try:
            time.sleep(0.5)
            fills = self.client.futures_account_trades(symbol=self.symbol, orderId=order_id)
            if fills:
                qty = sum(float(item["qty"]) for item in fills)
                quote = sum(float(item["qty"]) * float(item["price"]) for item in fills)
                usdt_commission = sum(
                    float(item["commission"])
                    for item in fills
                    if item.get("commissionAsset") == "USDT"
                )
                non_usdt = [item.get("commissionAsset") for item in fills if item.get("commissionAsset") != "USDT"]
                if non_usdt:
                    self.logger.warning("Order %s used non-USDT commission assets %s; log fee is incomplete.", order_id, non_usdt)
                return OrderFill(
                    order_id=str(order_id),
                    client_order_id=client_order_id,
                    quantity=qty,
                    average_price=quote / qty if qty else fallback_price,
                    commission_usdt=usdt_commission,
                    realized_pnl=sum(float(item.get("realizedPnl", 0.0)) for item in fills),
                    commission_is_estimate=bool(non_usdt),
                )
        except Exception as exc:
            self.logger.warning("Could not retrieve account fills for order %s: %s", order_id, exc)
        return OrderFill(
            order_id=str(order_id),
            client_order_id=client_order_id,
            quantity=fallback_qty,
            average_price=fallback_price,
            commission_usdt=fallback_qty * fallback_price * self.fee_rate,
            realized_pnl=0.0,
            commission_is_estimate=True,
        )

    def submit_delta(self, delta: float, current_qty: float, candle_time: pd.Timestamp, reason: str, fallback_price: float) -> OrderFill:
        if self.symbol_rules is None:
            raise BotError("Symbol rules are unavailable.")
        quantity = decimal_floor(abs(delta), self.symbol_rules.step_size)
        if quantity < self.symbol_rules.min_qty:
            raise BotError(f"Order delta {delta} rounds below Binance minimum quantity.")
        side = signed_side(delta)
        client_order_id = f"btclive{candle_time.strftime('%Y%m%d%H')}"
        close_only = abs(delta + current_qty) < float(self.symbol_rules.step_size) / 2.0
        params: dict[str, Any] = {
            "symbol": self.symbol,
            "side": side,
            "type": "MARKET",
            "quantity": decimal_text(quantity),
            "newClientOrderId": client_order_id,
            "newOrderRespType": "RESULT",
        }
        if close_only:
            params["reduceOnly"] = "true"
        if not self.is_live:
            cost = float(quantity) * fallback_price * self.cost_rate
            self.state["paper_equity"] = float(self.state.get("paper_equity", self.args.paper_equity)) - cost
            self.state["paper_position_qty"] = current_qty + math.copysign(float(quantity), delta)
            self.logger.warning(
                "DRY RUN order: %s %.6f %s at simulated %.2f; reason=%s; modeled cost=%.4f USDT.",
                side, float(quantity), self.symbol, fallback_price, reason, cost,
            )
            return OrderFill(
                order_id=f"dry-{client_order_id}",
                client_order_id=client_order_id,
                quantity=float(quantity),
                average_price=fallback_price,
                commission_usdt=cost,
                realized_pnl=0.0,
                commission_is_estimate=True,
            )
        try:
            response = self.client.futures_create_order(**params)
        except Exception as exc:
            self.logger.error("Order submission failed (%s). Checking idempotent client order ID %s.", exc, client_order_id)
            try:
                response = self.client.futures_get_order(symbol=self.symbol, origClientOrderId=client_order_id)
            except Exception:
                raise BotError(f"Order submission failed and no matching order could be recovered: {exc}") from exc
        status = str(response.get("status", ""))
        executed_qty = float(response.get("executedQty", 0.0))
        average_price = float(response.get("avgPrice", 0.0) or 0.0)
        if status != "FILLED" or executed_qty <= 0.0:
            raise BotError(f"Market order {client_order_id} is not fully filled: status={status}, executed={executed_qty}.")
        if average_price <= 0.0:
            average_price = fallback_price
        fill = self.current_live_order_fills(
            str(response["orderId"]), client_order_id, executed_qty, average_price
        )
        self.logger.info(
            "LIVE order filled: %s %.6f %s at %.2f; realized_pnl=%+.4f USDT; commission=%.4f USDT; reason=%s.",
            side, fill.quantity, self.symbol, fill.average_price, fill.realized_pnl, fill.commission_usdt, reason,
        )
        return fill

    def record_trade_transition(
        self,
        prior_qty: float,
        new_qty: float,
        fill: OrderFill,
        event_time: pd.Timestamp,
        equity_before: float,
        reason: str,
        decision_context: str,
    ) -> None:
        """Maintain a round-trip CSV from exchange fills across resizes/reversals."""
        active = self.state.get("active_trade")
        prior_sign = int(np.sign(prior_qty))
        new_sign = int(np.sign(new_qty))
        executed = abs(fill.quantity)
        close_qty = min(abs(prior_qty), executed) if prior_sign and (new_sign != prior_sign or abs(new_qty) < abs(prior_qty)) else 0.0
        close_fee = fill.commission_usdt * (close_qty / executed) if executed else 0.0
        open_fee = fill.commission_usdt - close_fee

        if active is not None and close_qty > 0.0:
            realized = fill.realized_pnl
            if fill.commission_is_estimate and realized == 0.0:
                price_move = (fill.average_price - float(active["entry_price"])) * (1.0 if active["direction"] == "long" else -1.0)
                realized = price_move * close_qty
            active["net_pnl"] = float(active.get("net_pnl", 0.0)) + realized - close_fee

        fully_closed = prior_sign != 0 and new_sign != prior_sign
        if fully_closed and active is not None:
            entry_time = pd.Timestamp(active["entry_time"])
            net_pnl = float(active["net_pnl"])
            entry_equity = float(active["entry_equity"])
            row = {
                "symbol": self.symbol,
                "entry_time": iso_time(entry_time),
                "exit_time": iso_time(event_time),
                "direction": active["direction"],
                "entry_price": float(active["entry_price"]),
                "exit_price": fill.average_price,
                "net_pnl": net_pnl,
                "ret_pct": (net_pnl / entry_equity * 100.0) if entry_equity > 0.0 else "",
                "duration_h": (event_time - entry_time).total_seconds() / 3600.0,
                "leverage": self.leverage,
                "reason": reason,
            }
            append_trade(self.trades_path, row)
            self.logger.info("Trade closed and appended to %s: %s, net_pnl=%+.4f USDT.", self.trades_path, reason, net_pnl)
            self.notify(
                f"{self.symbol} trade closed ({reason})\n{row['direction']} | entry {row['entry_price']:.2f} | "
                f"exit {row['exit_price']:.2f}\nnet P&L {net_pnl:+.4f} USDT | duration {row['duration_h']:.1f}h\n\n"
                f"{decision_context}"
            )
            active = None

        opened_new_trade = new_sign != 0 and new_sign != prior_sign
        if opened_new_trade:
            active = {
                "entry_time": iso_time(event_time),
                "direction": "long" if new_sign > 0 else "short",
                "entry_price": fill.average_price,
                "entry_equity": equity_before,
                "net_pnl": -open_fee,
            }
            self.logger.info("New %s trade opened at %.2f; entry fee %.4f USDT.", active["direction"], fill.average_price, open_fee)
            self.notify(
                f"{self.symbol} {active['direction'].upper()} opened\nfill={fill.average_price:.2f} | "
                f"qty={abs(new_qty):.6f} | leverage={self.leverage:g}x\nreason={reason}\n\n"
                f"{decision_context}"
            )
        elif active is not None and executed > 0.0:
            active["net_pnl"] = float(active.get("net_pnl", 0.0)) - open_fee

        self.state["active_trade"] = active
        self.state["live_position_qty" if self.is_live else "paper_position_qty"] = new_qty

    def process_latest_closed_candle(self) -> bool:
        candles = self.fetch_closed_signal_data()
        signal = bt.build_signal(candles, self.config)
        candle_open = candles.index[-1]
        candle_close_time = candle_open + self.bar_delta
        identifier = iso_time(candle_open)
        if same_instant(self.state.get("last_processed_candle"), candle_open):
            return False

        desired_unit = float(signal.iloc[-1])
        details, values = self.signal_details(candles, desired_unit)
        self.logger.info("New completed candle at %s to %s IST. Signal analysis: %s", iso_time(candle_open), iso_time(candle_close_time), details)
        self.paper_mark_to_close(float(candles["close"].iloc[-1]))
        equity = self.current_equity()
        current_qty = self.current_position_qty()
        mark_price = self.current_mark_price()
        cycle = self.ensure_cycle_state(candle_open, equity)
        cycle_start_equity = float(cycle["start_equity"])
        cycle_return = equity / cycle_start_equity - 1.0 if cycle_start_equity > 0.0 else -1.0
        current_notional = abs(current_qty) * mark_price
        estimated_exit_fraction = (current_notional / equity * self.cost_rate) if equity > 0.0 else 0.0
        net_after_exit_cycle_return = (equity * (1.0 - estimated_exit_fraction) / cycle_start_equity - 1.0)
        profit_lock = float(self.config.get("cycle_profit_lock_pct", 0.0)) / 100.0
        loss_stop = float(self.config.get("cycle_loss_stop_pct", 0.0)) / 100.0
        lock_reason = str(cycle.get("lock_reason", "")) if cycle.get("locked") else ""
        if not lock_reason and profit_lock > 0.0 and net_after_exit_cycle_return >= profit_lock:
            lock_reason = "cycle_profit_lock"
            cycle["locked"] = True
            cycle["lock_reason"] = lock_reason
            self.logger.warning(
                "Cycle profit lock triggered: gross=%+.3f%%, estimated net after exit=%+.3f%%, threshold=%+.3f%%.",
                cycle_return * 100.0, net_after_exit_cycle_return * 100.0, profit_lock * 100.0,
            )
        if not lock_reason and loss_stop > 0.0 and cycle_return <= -loss_stop:
            lock_reason = "cycle_loss_stop"
            cycle["locked"] = True
            cycle["lock_reason"] = lock_reason
            self.logger.warning("Cycle loss stop triggered at %+.3f%%, threshold=-%.3f%%.", cycle_return * 100.0, loss_stop * 100.0)

        next_cycle_start, _ = self.cycle_window(candle_close_time)
        is_next_cycle = not same_instant(next_cycle_start, cycle.get("start"))
        boundary_exit = bool(lock_reason and is_next_cycle)
        if is_next_cycle:
            self.advance_cycle_after_boundary(candle_close_time, equity)

        forced_flat = bool(lock_reason)
        effective_unit = 0.0 if forced_flat else desired_unit
        target_qty = self.target_quantity(effective_unit, equity, mark_price)
        delta = target_qty - current_qty
        size_blocked = effective_unit != 0.0 and abs(target_qty) < 1e-12
        reason = lock_reason or (
            "signal_reversal" if current_qty * target_qty < 0
            else "signal_entry" if abs(current_qty) < 1e-12 and abs(target_qty) >= 1e-12
            else "signal_rebalance"
        )
        if abs(target_qty) < 1e-12 and abs(current_qty) > 1e-12 and not lock_reason:
            reason = "signal_exit"
        if boundary_exit:
            reason = lock_reason

        min_delta = float(self.symbol_rules.step_size) / 2.0 if self.symbol_rules else 1e-12
        if lock_reason:
            action = "close position" if abs(current_qty) >= min_delta else "no order; cycle-locked and flat"
            rationale = f"{lock_reason} forces the effective signal to flat for this cycle"
        elif size_blocked:
            action = "close position" if abs(current_qty) >= min_delta else "no order; minimum size blocked entry"
            rules = self.symbol_rules
            min_qty = str(rules.min_qty) if rules else "unknown"
            min_notional = str(rules.min_notional) if rules else "unknown"
            rationale = (
                f"nonzero signal target is below exchange minimums "
                f"(min_qty={min_qty}, min_notional={min_notional} USDT); target set to flat"
            )
        elif desired_unit == 0.0:
            action = "close position" if abs(current_qty) >= min_delta else "no order; signal target is flat"
            rationale = "final strategy signal is flat after the indicator, volatility, ATR, and warmup checks above"
        elif abs(delta) < min_delta:
            action = "no order; current position matches target"
            rationale = "rounded target position does not differ enough to place an exchange order"
        elif abs(current_qty) < min_delta:
            action = f"open {'long' if target_qty > 0 else 'short'}"
            rationale = "final signal is directional and the rounded target position is nonzero"
        elif current_qty * target_qty < 0.0:
            action = f"reverse to {'long' if target_qty > 0 else 'short'}"
            rationale = "target direction is opposite the current position"
        elif abs(target_qty) < min_delta:
            action = "close position"
            rationale = "final target position is flat"
        elif abs(target_qty) > abs(current_qty):
            action = "increase position"
            rationale = "target exposure is larger than the current position"
        else:
            action = "reduce position"
            rationale = "target exposure is smaller than the current position"

        decision_context = (
            f"Candle close: {iso_time(candle_close_time)} IST\n"
            f"Decision: {action}. Rationale: {rationale}.\n"
            f"Signal conditions: {details}\n"
            f"Effective unit={effective_unit:+.4f}; current={current_qty:+.6f} BTC; "
            f"target={target_qty:+.6f} BTC; mark={mark_price:.2f}; equity={equity:.2f} USDT; "
            f"cycle return={cycle_return:+.2%}"
        )

        self.logger.info(
            "Decision: equity=%.4f USDT; mark=%.2f; current_qty=%+.6f; target_qty=%+.6f; delta=%+.6f; "
            "cycle=%s to %s; return=%+.3f%%; reason=%s.",
            equity, mark_price, current_qty, target_qty, delta,
            iso_time(cycle["start"]), iso_time(cycle["end"]), cycle_return * 100.0, reason,
        )
        self.logger.info(
            "Trade check: action=%s; rationale=%s; signal conditions: %s",
            action, rationale, details,
        )
        if self.shutdown_event.is_set() and abs(delta) >= min_delta:
            self.logger.info(
                "Shutdown requested before order submission; skipping this order, preserving the existing position, and saving state."
            )
            self.save_state()
            return False
        if abs(delta) >= min_delta:
            self.pending_decision_context = decision_context
            fill = self.submit_delta(delta, current_qty, candle_open, reason, mark_price)
            actual_qty = self.current_position_qty()
            expected_qty = current_qty + math.copysign(fill.quantity, delta)
            if abs(actual_qty - expected_qty) >= min_delta:
                raise BotError(
                    f"Post-order position mismatch: expected {expected_qty}, Binance reports {actual_qty}."
                )
            self.record_trade_transition(
                current_qty, actual_qty, fill, candle_close_time, equity, reason, decision_context
            )
            lifecycle_transition = (
                int(np.sign(current_qty)) != int(np.sign(actual_qty))
                and (abs(current_qty) >= min_delta or abs(actual_qty) >= min_delta)
            )
            if not lifecycle_transition:
                self.notify(
                    f"{self.symbol} {self.timeframe} candle decision; order filled\n"
                    f"fill={fill.average_price:.2f} | qty={fill.quantity:.6f} BTC\n\n{decision_context}"
                )
        else:
            self.logger.info(
                "No order placed. %s Signal=%+.4f; %s", rationale, desired_unit, details
            )
            self.notify(
                f"{self.symbol} {self.timeframe} closed candle — no order\n{details}\n"
                f"decision={action}: {rationale}\n"
                f"effective unit={effective_unit:+.4f}; current qty={current_qty:+.6f}; "
                f"target={target_qty:+.6f}; cycle={cycle_return:+.2%}"
            )

        self.state["last_processed_candle"] = identifier
        self.state["last_signal_unit"] = desired_unit
        self.state["last_signal_details"] = values
        self.save_state()
        self.pending_decision_context = None
        return True

    def run(self) -> None:
        previous_sigint_handler = signal.getsignal(signal.SIGINT)
        signal.signal(signal.SIGINT, self.request_shutdown)
        try:
            self.symbol_rules = self.fetch_symbol_rules()
            self.live_preflight()
            self.logger.info(self.startup_message().replace("\n", " | "))
            self.notify(self.startup_message())
            while not self.shutdown_event.is_set():
                try:
                    self.process_latest_closed_candle()
                    if self.args.once:
                        self.logger.info("--once requested; exiting after one complete check.")
                        return
                except KeyboardInterrupt:
                    # Covers an interrupt raised by code other than the installed
                    # SIGINT handler. Shutdown is still finalized in the finally block.
                    self.shutdown_event.set()
                except Exception as exc:
                    self.logger.exception("Cycle failed safely: %s", exc)
                    context = self.pending_decision_context
                    self.pending_decision_context = None
                    context_text = f"\n\nLast trade decision:\n{context}" if context else ""
                    self.notify(
                        f"{self.symbol} bot ERROR: {type(exc).__name__}: {exc}{context_text}\n"
                        f"Retrying in {self.args.retry_seconds}s."
                    )
                    if self.args.once:
                        raise
                    if self.shutdown_event.wait(max(5, int(self.args.retry_seconds))):
                        break
                    continue

                if self.shutdown_event.wait(max(5, int(self.args.poll_seconds))):
                    break
        finally:
            signal.signal(signal.SIGINT, previous_sigint_handler)
            if self.shutdown_event.is_set():
                try:
                    self.save_shutdown_state()
                except Exception as exc:
                    self.logger.exception("Could not safely save state during shutdown: %s", exc)
                    self.notify(
                        f"{self.symbol} bot stopped, but state saving failed: {type(exc).__name__}: {exc}. "
                        "Check the state file and Binance position before restarting."
                    )


def load_payload(config_path: Path) -> dict[str, Any]:
    try:
        payload = json.loads(config_path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise BotError(f"Configuration file not found: {config_path}") from exc
    except json.JSONDecodeError as exc:
        raise BotError(f"Invalid JSON in {config_path}: {exc}") from exc
    if not isinstance(payload, dict):
        raise BotError("Saved configuration must be a JSON object.")
    return payload


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Closed-candle Binance Futures executor for btc_backtester.py.")
    parser.add_argument("--config", default=str(DEFAULT_CONFIG), help="Saved best_config.json path.")
    parser.add_argument("--env-file", default=str(ROOT / ".env"), help="Optional KEY=value secrets file.")
    parser.add_argument(
        "--state",
        default=None,
        help="Persistent state JSON path (default depends on paper, testnet, or mainnet mode).",
    )
    parser.add_argument(
        "--trades",
        default=None,
        help="Round-trip trade CSV path (default depends on paper, testnet, or mainnet mode).",
    )
    parser.add_argument("--log-file", default=str(DEFAULT_LOG), help="Terminal log mirror path.")
    parser.add_argument("--poll-seconds", type=int, default=60, help="Polling interval while waiting for a closed candle.")
    parser.add_argument("--retry-seconds", type=int, default=60, help="Delay after a recoverable error.")
    parser.add_argument("--candle-settle-seconds", type=int, default=10, help="Wait after a close before treating Binance kline data as final.")
    parser.add_argument("--paper-equity", type=float, default=1000.0, help="Initial simulated USDT equity in dry-run mode.")
    parser.add_argument(
        "--margin-utilization",
        type=float,
        default=None,
        help="Fraction of equity available for position sizing (default: 90%% live/testnet, 100%% dry-run).",
    )
    parser.add_argument(
        "--backtest-parity",
        action="store_true",
        help=(
            "Size targets at 100%% of equity, matching the backtest's leverage exposure. "
            "This leaves no margin reserve and increases rejection/liquidation risk."
        ),
    )
    parser.add_argument("--live", action="store_true", help="Permit real USDⓈ-M Futures orders after all safety checks pass.")
    parser.add_argument("--testnet", action="store_true", help="Use Binance testnet for Futures account/order endpoints.")
    parser.add_argument("--once", action="store_true", help="Process one latest closed candle check and exit.")
    parser.add_argument("--verbose", action="store_true", help="Show DEBUG logs in the terminal too.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    logger = configure_logging(Path(args.log_file), args.verbose)
    load_env_file(Path(args.env_file), logger)
    try:
        if args.paper_equity <= 0.0:
            raise BotError("--paper-equity must be positive.")
        payload = load_payload(Path(args.config))
        bot = BinanceLiveBot(args, payload, logger)
        bot.run()
    except BotError as exc:
        logger.critical("Bot did not start: %s", exc)
        raise SystemExit(2) from exc


if __name__ == "__main__":
    main()
