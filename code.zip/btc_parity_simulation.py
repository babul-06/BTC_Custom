"""Offline comparison of the saved backtest and the live bot's sizing mechanics.

This replay never creates a Binance client and never places orders. It uses the
same local 1h spot candle file as the backtester, resamples to the saved
timeframe, and models market-order costs on each actual quantity adjustment.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Any

import pandas as pd

import btc_backtester as bt
from btc_live_bot import size_target_quantity


ROOT = Path(__file__).resolve().parent
DEFAULT_CONFIG = ROOT / "reports" / "best_config.json"
DEFAULT_OUTPUT_ROOT = ROOT / "reports"


def load_candles(path: Path) -> pd.DataFrame:
    source = pd.read_csv(path, parse_dates=["open_time"], index_col="open_time")
    source.index = pd.DatetimeIndex(source.index)
    if source.index.tz is None:
        source.index = source.index.tz_localize("UTC")
    else:
        source.index = source.index.tz_convert("UTC")
    source = source.sort_index()
    required = {"open", "high", "low", "close", "volume"}
    missing = required - set(source.columns)
    if missing:
        raise RuntimeError(f"Candle file {path} is missing columns: {sorted(missing)}")
    return source


def find_local_candles(symbol: str, data_arg: str | None) -> Path:
    if data_arg:
        candidate = Path(data_arg)
        if not candidate.is_absolute():
            candidate = ROOT / candidate
        if not candidate.exists():
            raise RuntimeError(f"Candle file does not exist: {candidate}")
        return candidate
    candidates = list((ROOT / "data").glob(f"{symbol}_1h_*.csv"))
    if not candidates:
        raise RuntimeError(f"No local 1h candle cache found for {symbol} under {ROOT / 'data'}.")
    return max(candidates, key=lambda item: item.stat().st_mtime)


def live_quantity_replay(
    df: pd.DataFrame,
    signal: pd.Series,
    payload: dict[str, Any],
    *,
    initial_equity: float,
    step_size: float,
    min_qty: float,
    min_notional: float,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Replay live target sizing with close fills and modeled all-in costs."""
    one_bar_returns, requested_units = bt.prepare_backtest_inputs(
        df=df,
        signal=signal,
        start=str(payload["start"]),
        end=str(payload["end"]),
    )
    previous_close = df["close"].astype(float).shift(1).reindex(one_bar_returns.index)
    current_close = df["close"].astype(float).reindex(one_bar_returns.index)
    leverage = float(payload["leverage"])
    cost_rate = (float(payload["fee_bps"]) + float(payload["slippage_bps"])) / 10_000.0
    profit_lock = float(payload["config"].get("cycle_profit_lock_pct", 0.0)) / 100.0
    loss_stop = float(payload["config"].get("cycle_loss_stop_pct", 0.0)) / 100.0
    start_ts = bt.utc_timestamp(str(payload["start"]))
    end_ts = bt.utc_timestamp(str(payload["end"]))
    cycle_start = start_ts
    cycle_end = min(cycle_start + pd.DateOffset(months=2), end_ts)

    equity = float(initial_equity)
    cycle_start_equity = equity
    current_qty = 0.0
    locked = False
    lock_reason = ""
    blown_up = False
    path_rows: list[dict[str, Any]] = []
    order_rows: list[dict[str, Any]] = []

    for ts, bar_return in one_bar_returns.items():
        boundary_exit_reason = ""
        while ts >= cycle_end and cycle_end < end_ts:
            if locked and abs(current_qty) >= step_size / 2.0:
                boundary_exit_reason = lock_reason
            cycle_start = cycle_end
            cycle_end = min(cycle_start + pd.DateOffset(months=2), end_ts)
            cycle_start_equity = max(equity, 1e-12)
            locked = False
            lock_reason = ""

        desired_unit = (
            0.0
            if boundary_exit_reason or locked or blown_up
            else float(requested_units.loc[ts])
        )
        fill_price = float(previous_close.loc[ts]) if pd.notna(previous_close.loc[ts]) else float(df.loc[ts, "open"])
        mark_price = float(current_close.loc[ts])
        equity_before = equity

        _, target_qty = size_target_quantity(
            desired_unit=desired_unit,
            equity=equity_before,
            mark_price=fill_price,
            leverage=leverage,
            margin_utilization=1.0,
            step_size=step_size,
            min_qty=min_qty,
            min_notional=min_notional,
        )
        delta_qty = target_qty - current_qty
        order_cost = abs(delta_qty) * fill_price * cost_rate
        order_notional = abs(delta_qty) * fill_price

        if abs(delta_qty) >= step_size / 2.0:
            if boundary_exit_reason:
                order_reason = boundary_exit_reason
            elif locked:
                order_reason = lock_reason or "cycle_lock"
            elif current_qty * target_qty < 0.0:
                order_reason = "signal_reversal"
            elif abs(current_qty) < step_size / 2.0:
                order_reason = "signal_entry"
            elif abs(target_qty) < step_size / 2.0:
                order_reason = "signal_exit"
            elif current_qty * target_qty > 0.0:
                order_reason = "same_direction_rebalance"
            else:
                order_reason = "position_adjustment"
            order_rows.append(
                {
                    "timestamp_ist": bt.ist_iso(ts),
                    "side": "BUY" if delta_qty > 0.0 else "SELL",
                    "reason": order_reason,
                    "signal_unit": desired_unit,
                    "fill_price": fill_price,
                    "delta_qty_btc": abs(delta_qty),
                    "target_qty_btc": target_qty,
                    "notional_usdt": order_notional,
                    "modeled_cost_usdt": order_cost,
                }
            )

        equity_after_cost = equity_before - order_cost
        bar_pnl = target_qty * (mark_price - fill_price)
        equity = equity_after_cost + bar_pnl
        if not math.isfinite(equity) or equity <= 0.0:
            equity = 0.0
            blown_up = True
        step_return = equity / equity_before - 1.0 if equity_before > 0.0 else -1.0

        cycle_return = equity / cycle_start_equity - 1.0 if cycle_start_equity > 0.0 else -1.0
        estimated_exit_cost = abs(target_qty) * mark_price * cost_rate
        return_after_exit = (
            (equity - estimated_exit_cost) / cycle_start_equity - 1.0
            if cycle_start_equity > 0.0
            else -1.0
        )
        if not blown_up and profit_lock > 0.0 and return_after_exit >= profit_lock:
            locked = True
            lock_reason = "cycle_profit_lock"
        if not blown_up and loss_stop > 0.0 and cycle_return <= -loss_stop:
            locked = True
            lock_reason = "cycle_loss_stop"

        path_rows.append(
            {
                "timestamp_utc": ts,
                "equity": equity,
                "return": step_return,
                "requested_unit": float(requested_units.loc[ts]),
                "effective_unit": desired_unit,
                "target_qty_btc": target_qty,
                "delta_qty_btc": delta_qty,
                "mark_price": mark_price,
                "order_cost_usdt": order_cost,
                "cycle_return": cycle_return,
                "locked": locked,
                "lock_reason": lock_reason,
                "blown_up": blown_up,
            }
        )
        current_qty = target_qty

    return pd.DataFrame(path_rows).set_index("timestamp_utc"), pd.DataFrame(order_rows)


def summarize_window(
    equity: pd.Series,
    returns: pd.Series,
    units: pd.Series,
    window_start: pd.Timestamp,
    window_end: pd.Timestamp,
    *,
    orders: pd.DataFrame | None = None,
    initial_equity: float = 1.0,
    timeframe: str = "12h",
) -> dict[str, Any]:
    mask = (equity.index >= window_start) & (equity.index < window_end)
    selected_equity = equity.loc[mask].astype(float)
    selected_returns = returns.reindex(selected_equity.index).astype(float)
    if selected_equity.empty:
        raise RuntimeError(f"No completed bars in requested window {window_start} to {window_end}.")
    earlier = equity.loc[equity.index < window_start]
    starting_equity = float(earlier.iloc[-1]) if not earlier.empty else float(initial_equity)
    path = pd.concat([pd.Series([starting_equity]), selected_equity.reset_index(drop=True)], ignore_index=True)
    drawdown = path / path.cummax() - 1.0
    std = float(selected_returns.std(ddof=0))
    sharpe = (
        float(selected_returns.mean() / std * math.sqrt(bt.bars_per_year_for_timeframe(timeframe)))
        if std > 0.0
        else 0.0
    )
    unit_changes = units.diff().abs().fillna(units.abs())
    selected_changes = unit_changes.loc[mask]
    normalization = float(initial_equity) / starting_equity if starting_equity > 0.0 else 0.0
    result: dict[str, Any] = {
        "window_start_utc": window_start.isoformat(),
        "window_end_exclusive_utc": window_end.isoformat(),
        "normalized_start_equity_usdt": float(initial_equity),
        "normalized_end_equity_usdt": float(selected_equity.iloc[-1] * normalization),
        "unscaled_full_run_equity_at_window_start_usdt": starting_equity,
        "equity_multiple": float(selected_equity.iloc[-1] / starting_equity),
        "return_pct": float((selected_equity.iloc[-1] / starting_equity - 1.0) * 100.0),
        "max_drawdown_pct": float(drawdown.min() * 100.0),
        "sharpe_like": sharpe,
        "active_candles": int((units.loc[mask].abs() > 0.01).sum()),
        "position_factor_changes": int((selected_changes > 0.01).sum()),
        "bars": int(len(selected_equity)),
    }
    if orders is not None:
        if orders.empty:
            selected_orders = orders
        else:
            order_times = pd.to_datetime(orders["timestamp_ist"], utc=True)
            selected_orders = orders.loc[(order_times >= window_start) & (order_times < window_end)]
        result["orders"] = int(len(selected_orders))
        result["same_direction_rebalances"] = int(
            selected_orders["reason"].eq("same_direction_rebalance").sum()
        ) if not selected_orders.empty else 0
        raw_cost = float(selected_orders["modeled_cost_usdt"].sum()) if not selected_orders.empty else 0.0
        result["modeled_cost_usdt"] = raw_cost * normalization
    return result


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Offline comparison of backtest and live sizing mechanics.")
    parser.add_argument("--config", default=str(DEFAULT_CONFIG))
    parser.add_argument("--data", default=None, help="Local cached Binance spot 1h CSV; no network fetch is performed.")
    parser.add_argument("--initial-equity", type=float, default=10_000.0)
    parser.add_argument("--step-size", type=float, default=0.0001, help="BTC quantity increment (observed in server log).")
    parser.add_argument("--min-qty", type=float, default=0.0001)
    parser.add_argument("--min-notional", type=float, default=50.0)
    parser.add_argument("--full-period", action="store_true", help="Report the full saved-config period instead of only the trailing two months.")
    parser.add_argument("--output", default=None, help="Output directory; defaults to a dated folder under reports/.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    config_path = Path(args.config)
    if not config_path.is_absolute():
        config_path = ROOT / config_path
    payload = json.loads(config_path.read_text(encoding="utf-8"))
    data_path = find_local_candles(str(payload["symbol"]).upper(), args.data)
    source = load_candles(data_path)
    timeframe = str(payload["timeframe"])
    df = bt.resample_ohlcv(source, timeframe)
    signal = bt.build_signal(df, payload["config"])

    start = str(payload["start"])
    end = str(payload["end"])
    configured_start = bt.utc_timestamp(start)
    sim_end = bt.utc_timestamp(end)
    sim_start = configured_start if args.full_period else sim_end - pd.DateOffset(months=2)
    initial_equity = float(args.initial_equity)
    cost_rate = (float(payload["fee_bps"]) + float(payload["slippage_bps"])) / 10_000.0
    one_bar_returns, base_units = bt.prepare_backtest_inputs(df, signal, start, end)
    bt_path = bt.build_execution_path(
        bar_returns=one_bar_returns,
        base_unit_position=base_units,
        leverage=float(payload["leverage"]),
        cost_rate=cost_rate,
        start=start,
        end=end,
        profit_lock=float(payload["config"].get("cycle_profit_lock_pct", 0.0)) / 100.0,
        loss_stop=float(payload["config"].get("cycle_loss_stop_pct", 0.0)) / 100.0,
    )
    bt_equity_usdt = bt_path.equity * initial_equity
    bt_return_usdt = bt_path.returns
    bt_units = bt_path.unit_position
    backtest_summary = summarize_window(
        bt_equity_usdt,
        bt_return_usdt,
        bt_units,
        sim_start,
        sim_end,
        initial_equity=initial_equity,
        timeframe=timeframe,
    )

    venue_profiles = {
        "binance_mainnet_offline_profile": {
            "step_size": float(args.step_size),
            "min_qty": float(args.min_qty),
            "min_notional": float(args.min_notional),
        },
        "binance_testnet_offline_profile": {
            "step_size": float(args.step_size),
            "min_qty": float(args.min_qty),
            "min_notional": float(args.min_notional),
        },
    }
    replay_results: dict[str, Any] = {}
    replay_paths: dict[str, pd.DataFrame] = {}
    all_orders: list[pd.DataFrame] = []
    for name, rules in venue_profiles.items():
        replay_path, orders = live_quantity_replay(
            df,
            signal,
            payload,
            initial_equity=initial_equity,
            step_size=rules["step_size"],
            min_qty=rules["min_qty"],
            min_notional=rules["min_notional"],
        )
        replay_paths[name] = replay_path
        all_orders.append(orders.assign(profile=name))
        replay_returns = replay_path["return"]
        replay_equity = replay_path["equity"]
        replay_units = replay_path["effective_unit"]
        replay_summary = summarize_window(
            replay_equity,
            replay_returns,
            replay_units,
            sim_start,
            sim_end,
            orders=orders,
            initial_equity=initial_equity,
            timeframe=timeframe,
        )
        replay_summary["margin_utilization"] = 1.0
        replay_summary["step_size_btc"] = rules["step_size"]
        replay_results[name] = replay_summary

    backtest_cycles = bt.cycle_returns(
        bt_path.equity * initial_equity,
        start,
        end,
        initial_equity=initial_equity,
    )
    cycle_table = pd.DataFrame(
        {
            "cycle_start_ist": [cycle["start"] for cycle in backtest_cycles],
            "cycle_end_ist": [cycle["end"] for cycle in backtest_cycles],
            "backtest_return_pct": [cycle["return_pct"] for cycle in backtest_cycles],
        }
    )
    for name, label in (
        ("binance_mainnet_offline_profile", "mainnet_return_pct"),
        ("binance_testnet_offline_profile", "testnet_return_pct"),
    ):
        replay_cycles = bt.cycle_returns(
            replay_paths[name]["equity"],
            start,
            end,
            initial_equity=initial_equity,
        )
        cycle_table[label] = [cycle["return_pct"] for cycle in replay_cycles]

    cycle_starts_utc = pd.to_datetime(cycle_table["cycle_start_ist"], utc=True)
    cycle_table = cycle_table.loc[
        (cycle_starts_utc >= sim_start) & (cycle_starts_utc < sim_end)
    ].reset_index(drop=True)
    cycle_table["mainnet_minus_backtest_pp"] = (
        cycle_table["mainnet_return_pct"] - cycle_table["backtest_return_pct"]
    )
    cycle_table["testnet_minus_backtest_pp"] = (
        cycle_table["testnet_return_pct"] - cycle_table["backtest_return_pct"]
    )

    comparisons = {}
    for name, summary in replay_results.items():
        comparisons[name] = {
            "return_difference_percentage_points": summary["return_pct"] - backtest_summary["return_pct"],
            "max_drawdown_difference_percentage_points": summary["max_drawdown_pct"] - backtest_summary["max_drawdown_pct"],
        }

    output_dir = Path(args.output) if args.output else DEFAULT_OUTPUT_ROOT / (
        f"parity_replay_{sim_start.strftime('%Y-%m-%d')}_{sim_end.strftime('%Y-%m-%d')}"
    )
    if not output_dir.is_absolute():
        output_dir = ROOT / output_dir
    output_dir.mkdir(parents=True, exist_ok=True)

    order_frame = pd.concat([orders for orders in all_orders if not orders.empty], ignore_index=True) if any(
        not orders.empty for orders in all_orders
    ) else pd.DataFrame()
    order_frame.to_csv(output_dir / "live_replay_orders.csv", index=False)
    cycle_table.to_csv(output_dir / "bimonthly_comparison.csv", index=False)
    for name, path in replay_paths.items():
        path.to_csv(output_dir / f"{name}_equity.csv", index_label="timestamp_utc")

    report = {
        "simulation_type": "offline historical replay; no Binance account calls and no orders",
        "config": str(config_path),
        "data_file": str(data_path),
        "data_source": "local Binance spot 1h cache; same signal feed used by the bot/backtester",
        "best_config": {
            "symbol": payload["symbol"],
            "timeframe": timeframe,
            "leverage": float(payload["leverage"]),
            "fee_bps": float(payload["fee_bps"]),
            "slippage_bps": float(payload["slippage_bps"]),
            "strategy_config": payload["config"],
        },
        "requested_window": {
            "start_utc": sim_start.isoformat(),
            "end_exclusive_utc": sim_end.isoformat(),
            "bars": int(((one_bar_returns.index >= sim_start) & (one_bar_returns.index < sim_end)).sum()),
        },
        "full_replay_seed_equity_usdt": initial_equity,
        "window_reporting_equity_usdt": initial_equity,
        "cycle_state_seed_date": str(payload["start"]),
        "backtester": backtest_summary,
        "live_bot_quantity_replay": replay_results,
        "difference_vs_backtester": comparisons,
        "bimonthly_comparison": cycle_table.to_dict(orient="records"),
        "venue_limitations": (
            "Mainnet and testnet rows are simulated profiles, not exchange executions. Both use the same local "
            "spot candles and the same 0.0001 BTC step/minimum assumptions observed in the server log. Current "
            "exchange filters were not retrieved. No orders were submitted to either environment."
        ),
        "model_limitations": (
            "The replay models close-price fills, lot rounding, and the saved 4 bp fee + 1 bp slippage on every "
            "actual quantity adjustment. It does not model funding, liquidation/maintenance margin, latency, "
            "spread changes, partial fills, or differences between mark/close/execution prices."
        ),
    }
    (output_dir / "summary.json").write_text(json.dumps(report, indent=2), encoding="utf-8")

    title = (
        "# Full-period backtest / live-logic bimonthly comparison"
        if args.full_period
        else "# Two-month backtest / live-logic parity replay"
    )
    lines = [
        title,
        "",
        f"Window: {bt.ist_iso(sim_start)} through {bt.ist_iso(sim_end)} (end exclusive); results rebased to {initial_equity:,.2f} USDT at window start.",
        f"Config: `{config_path.name}`; {payload['symbol']} {timeframe}; {float(payload['leverage']):g}x; "
        f"profit lock={float(payload['config'].get('cycle_profit_lock_pct', 0.0)):g}% per two-month cycle; "
        f"fees/slippage={float(payload['fee_bps']):g}/{float(payload['slippage_bps']):g} bps.",
        f"Data: `{data_path.name}` (local Binance spot 1h cache). To preserve cycle-lock state, both paths were seeded from {payload['start']} with {initial_equity:,.2f} USDT before the displayed window.",
        f"Sizing/filters: 100% equity (backtest-parity), {float(args.step_size):g} BTC step and min quantity, {float(args.min_notional):g} USDT minimum notional.",
        "",
        "| Model | Return | Max drawdown | End equity | Orders / factor changes | Modeled order costs |",
        "|---|---:|---:|---:|---:|---:|",
        f"| Existing backtester | {backtest_summary['return_pct']:+.3f}% | {backtest_summary['max_drawdown_pct']:.3f}% | {backtest_summary['normalized_end_equity_usdt']:,.2f} | {backtest_summary['position_factor_changes']} factor changes | included in model |",
    ]
    for name, result in replay_results.items():
        lines.append(
            f"| {name} | {result['return_pct']:+.3f}% | {result['max_drawdown_pct']:.3f}% | "
            f"{result['normalized_end_equity_usdt']:,.2f} | {result['orders']} orders ({result['same_direction_rebalances']} same-direction rebalances) | "
            f"{result['modeled_cost_usdt']:,.2f} USDT |"
        )
    lines.extend(
        [
            "",
            "## Bimonthly returns",
            "",
            "| Cycle start (IST) | Cycle end (IST, exclusive) | Backtest | Mainnet profile | Testnet profile | Mainnet minus backtest | Testnet minus backtest |",
            "|---|---|---:|---:|---:|---:|---:|",
        ]
    )
    for row in cycle_table.to_dict(orient="records"):
        lines.append(
            f"| {row['cycle_start_ist']} | {row['cycle_end_ist']} | "
            f"{row['backtest_return_pct']:+.3f}% | {row['mainnet_return_pct']:+.3f}% | "
            f"{row['testnet_return_pct']:+.3f}% | {row['mainnet_minus_backtest_pp']:+.3f} pp | "
            f"{row['testnet_minus_backtest_pp']:+.3f} pp |"
        )
    lines.extend(
        [
            "",
            "## Interpretation",
            "",
            "The live-logic replay recalculates BTC quantity from current equity and price at every completed candle. "
            "It charges the configured all-in cost on each resulting quantity change; the existing backtester only "
            "charges turnover when its normalized position factor changes. This is the main expected source of "
            "difference while the signal stays at the same unit.",
            "",
            "The mainnet/testnet rows are offline venue profiles, not proof of actual exchange fills. They are equal "
            "because this replay deliberately uses the same public spot candles, quantity filters, close fills, and "
            "cost assumptions for both. No orders were submitted to either environment.",
            "",
            "## Limitations",
            "",
            report["venue_limitations"],
            "",
            report["model_limitations"],
            "",
            "Artifacts: `summary.json`, `bimonthly_comparison.csv`, `live_replay_orders.csv`, and one equity CSV per simulated venue profile.",
        ]
    )
    (output_dir / "summary.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({"output_dir": str(output_dir), "backtester": backtest_summary, "live_bot_quantity_replay": replay_results, "difference_vs_backtester": comparisons}, indent=2))


if __name__ == "__main__":
    main()
